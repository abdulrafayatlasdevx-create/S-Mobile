// =========================================================
// ADMIN.JS — protected admin dashboard
// =========================================================
// SECURITY NOTE: this file gates the UI for convenience only. The real
// authorization boundary is Firestore security rules (see /firebase-rules
// notes in the project plan) which reject writes from any account whose
// `role` field is not "admin" — this client-side check can be bypassed
// and must never be trusted as the sole protection.

import { auth, db, firebaseReady } from "./firebase.js";
import { onAuthChange, getCurrentUser, getCurrentRole } from "./auth.js";
import {
  collection, getDocs, doc, updateDoc, addDoc, deleteDoc, query, orderBy
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const els = {
  gate: document.getElementById("adminGate"),
  panel: document.getElementById("adminPanel"),
  productsBody: document.getElementById("adminProductsBody"),
  ordersBody: document.getElementById("adminOrdersBody"),
  usersBody: document.getElementById("adminUsersBody"),
  addForm: document.getElementById("adminAddForm"),
  statusMsg: document.getElementById("adminStatusMsg")
};

function showStatus(msg, ok = true) {
  if (!els.statusMsg) return;
  els.statusMsg.textContent = msg;
  els.statusMsg.className = `form-msg show ${ok ? "success" : "error"}`;
  setTimeout(() => els.statusMsg.classList.remove("show"), 3500);
}

async function loadProducts() {
  if (!firebaseReady || !els.productsBody) return;
  try {
    const snap = await getDocs(collection(db, "products"));
    els.productsBody.innerHTML = snap.docs.map(d => {
      const p = d.data();
      return `<tr data-id="${d.id}">
        <td>${p.brand || ""} ${p.model || ""}</td>
        <td>${p.ram || "—"}/${p.storage || "—"}</td>
        <td><input type="number" class="edit-price" value="${p.wholesalePrice ?? ""}" placeholder="PKR"></td>
        <td><input type="number" class="edit-stock" value="${p.stock ?? ""}" placeholder="qty"></td>
        <td>
          <button class="btn btn-sm btn-ghost save-row">Save</button>
          <button class="btn btn-sm btn-ghost delete-row" style="color:var(--danger)">Delete</button>
        </td>
      </tr>`;
    }).join("") || `<tr><td colspan="5">No products in Firestore yet — add one below.</td></tr>`;

    els.productsBody.querySelectorAll(".save-row").forEach(btn => {
      btn.addEventListener("click", async (e) => {
        const row = e.target.closest("tr");
        const id = row.dataset.id;
        const price = parseInt(row.querySelector(".edit-price").value, 10) || null;
        const stock = parseInt(row.querySelector(".edit-stock").value, 10);
        try {
          await updateDoc(doc(db, "products", id), {
            wholesalePrice: price,
            stock: isNaN(stock) ? null : stock
          });
          showStatus("Product updated.");
        } catch (err) {
          showStatus("Update failed — check your permissions.", false);
        }
      });
    });

    els.productsBody.querySelectorAll(".delete-row").forEach(btn => {
      btn.addEventListener("click", async (e) => {
        const row = e.target.closest("tr");
        if (!confirm("Delete this product permanently?")) return;
        try {
          await deleteDoc(doc(db, "products", row.dataset.id));
          row.remove();
          showStatus("Product deleted.");
        } catch (err) {
          showStatus("Delete failed — check your permissions.", false);
        }
      });
    });
  } catch (err) {
    showStatus("Could not load products from Firestore.", false);
  }
}

async function loadOrders() {
  if (!firebaseReady || !els.ordersBody) return;
  try {
    const q = query(collection(db, "orders"), orderBy("createdAt", "desc"));
    const snap = await getDocs(q);
    els.ordersBody.innerHTML = snap.docs.map(d => {
      const o = d.data();
      const items = (o.items || []).map(i => `${i.brand} ${i.model} x${i.qty}`).join(", ");
      return `<tr>
        <td>${o.name || "—"}</td>
        <td>${o.phone || "—"}</td>
        <td>${items}</td>
        <td>PKR ${(o.subtotal || 0).toLocaleString()}</td>
        <td>${o.status || "pending"}</td>
      </tr>`;
    }).join("") || `<tr><td colspan="5">No order requests yet.</td></tr>`;
  } catch (err) {
    els.ordersBody.innerHTML = `<tr><td colspan="5">Could not load orders.</td></tr>`;
  }
}

async function loadUsers() {
  if (!firebaseReady || !els.usersBody) return;
  try {
    const snap = await getDocs(collection(db, "users"));
    els.usersBody.innerHTML = snap.docs.map(d => {
      const u = d.data();
      return `<tr><td>${u.name || "—"}</td><td>${u.email || "—"}</td><td>${u.role || "customer"}</td></tr>`;
    }).join("") || `<tr><td colspan="3">No registered users yet.</td></tr>`;
  } catch (err) {
    els.usersBody.innerHTML = `<tr><td colspan="3">Could not load users.</td></tr>`;
  }
}

els.addForm?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = new FormData(els.addForm);
  const newProduct = {
    brand: fd.get("brand"), model: fd.get("model"),
    ram: fd.get("ram") || "—", storage: fd.get("storage") || "—",
    wholesalePrice: parseInt(fd.get("price"), 10) || null,
    stock: parseInt(fd.get("stock"), 10) || null,
    image: fd.get("image") || ""
  };
  try {
    await addDoc(collection(db, "products"), newProduct);
    showStatus("Product added.");
    els.addForm.reset();
    loadProducts();
  } catch (err) {
    showStatus("Could not add product — check Firebase connection/permissions.", false);
  }
});

function renderGateState(user, role) {
  if (!els.gate) return;
  if (!firebaseReady) {
    els.gate.innerHTML = `<p>Admin dashboard requires Firebase to be configured (see firebase.js). Once connected, sign in with an admin account to continue.</p>`;
    els.panel?.classList.add("hidden");
    return;
  }
  if (!user) {
    els.gate.innerHTML = `<p>Please <a href="../index.html#login" style="color:var(--gold)">log in</a> with an admin account to view this dashboard.</p>`;
    els.panel?.classList.add("hidden");
    return;
  }
  if (role !== "admin") {
    els.gate.innerHTML = `<p>Your account (${user.email}) does not have admin access. Firestore rules block any write attempt regardless of what this page shows.</p>`;
    els.panel?.classList.add("hidden");
    return;
  }
  els.gate.innerHTML = "";
  els.panel?.classList.remove("hidden");
  loadProducts();
  loadOrders();
  loadUsers();
}

onAuthChange(renderGateState);
renderGateState(getCurrentUser(), getCurrentRole());
