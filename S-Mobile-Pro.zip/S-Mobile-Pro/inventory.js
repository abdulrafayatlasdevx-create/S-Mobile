// =========================================================
// INVENTORY.JS — product data + rendering + search/filter
// =========================================================
// DATA HONESTY NOTE:
// Only the figures actually supplied are used. Where a price *range* was
// given, both bounds are stored and the exact wholesalePrice is left null
// until an admin locks it in. No stock quantity was supplied for any
// product in the source data, so every item ships with stock: null
// ("on request") until the admin sets a real number. Nothing here is invented.

export const FALLBACK_IMAGE =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'>
    <rect width='200' height='200' fill='#151b2b'/>
    <rect x='70' y='40' width='60' height='120' rx='10' fill='none' stroke='#E8A33D' stroke-width='2'/>
    <text x='100' y='185' font-family='Inter' font-size='11' fill='#6B7280' text-anchor='middle'>Image coming soon</text>
  </svg>`);

// id, brand, model, ram, storage, priceMin, priceMax, wholesalePrice(null=not locked), stock(null=on request), availability
export const PRODUCTS = [
  // ---------------- VIVO ----------------
  { id: "vivo-y05-4-64",  brand: "Vivo", model: "Y05",  ram: "4GB", storage: "64GB",  priceMin: 31500, priceMax: 32500, wholesalePrice: null, stock: null },
  { id: "vivo-y05-4-128", brand: "Vivo", model: "Y05",  ram: "4GB", storage: "128GB", priceMin: 35000, priceMax: 36000, wholesalePrice: null, stock: null },
  { id: "vivo-v50lite-8-128", brand: "Vivo", model: "V50 Lite 5G", ram: "8GB", storage: "128GB", priceMin: 68000, priceMax: 70000, wholesalePrice: null, stock: null },
  { id: "vivo-xfold5-16-512", brand: "Vivo", model: "X Fold5", ram: "16GB", storage: "512GB", priceMin: 340000, priceMax: 355000, wholesalePrice: null, stock: null },
  { id: "vivo-y05e-4-64", brand: "Vivo", model: "Y05e", ram: "4GB", storage: "64GB", priceMin: 29500, priceMax: 30500, wholesalePrice: null, stock: null },
  { id: "vivo-y31d", brand: "Vivo", model: "Y31d", ram: "—", storage: "—", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, pending: true },

  // ---------------- OPPO ----------------
  { id: "oppo-a6spro", brand: "OPPO", model: "A6S Pro", ram: "—", storage: "—", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, pending: true },
  { id: "oppo-reno16a5g", brand: "OPPO", model: "Reno16 A5G", ram: "—", storage: "—", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, pending: true },

  // ---------------- REDMI / XIAOMI ----------------
  { id: "redmi-15c", brand: "Redmi", model: "15C", ram: "—", storage: "—", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, pending: true },
  { id: "redmi-a7pro", brand: "Redmi", model: "A7 Pro", ram: "—", storage: "—", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, pending: true },

  // ---------------- ONEPLUS ----------------
  { id: "oneplus-nord60x", brand: "OnePlus", model: "Nord 60X", ram: "—", storage: "—", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, pending: true },

  // ---------------- SAMSUNG ----------------
  { id: "samsung-a07", brand: "Samsung", model: "A07", ram: "—", storage: "—", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, pending: true },

  // ---------------- INFINIX ----------------
  { id: "infinix-smart20", brand: "Infinix", model: "Smart 20", ram: "—", storage: "—", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, pending: true },

  // ---------------- TECNO ----------------
  { id: "tecno-sparkgo3", brand: "Tecno", model: "Spark Go 3", ram: "—", storage: "—", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, pending: true },
  { id: "tecno-hot60", brand: "Tecno", model: "Hot 60", ram: "—", storage: "—", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, pending: true },
  { id: "tecno-hot60pro", brand: "Tecno", model: "Hot 60 Pro", ram: "—", storage: "—", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, pending: true },
  { id: "tecno-hot70", brand: "Tecno", model: "Hot 70", ram: "—", storage: "—", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, pending: true },

  // ---------------- NUBIA ----------------
  { id: "nubia-886", brand: "Nubia", model: "886", ram: "—", storage: "—", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, pending: true },

  // ---------------- Flagship detail-page products also listed in grid ----------------
  { id: "vivo-x300-fe", brand: "Vivo", model: "X300 FE", ram: "12GB", storage: "256GB", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, detailPage: "products/vivo-x300-fe.html", officialPrice: 269999 },
  { id: "vivo-v80-lite-8-128", brand: "Vivo", model: "V80 Lite 5G", ram: "8GB", storage: "128GB", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, detailPage: "products/vivo-v80-lite-5g.html", officialPrice: 124999 },
  { id: "vivo-v80-lite-8-256", brand: "Vivo", model: "V80 Lite 5G", ram: "8GB", storage: "256GB", priceMin: null, priceMax: null, wholesalePrice: null, stock: null, detailPage: "products/vivo-v80-lite-5g.html", officialPrice: 145999 }
];

export const BRANDS = ["Vivo", "OPPO", "Redmi", "OnePlus", "Samsung", "Infinix", "Tecno", "Nubia"];

// ---- Derived helpers ----
export function availabilityOf(p) {
  if (p.pending) return "on-request";
  if (p.stock === null || p.stock === undefined) return "on-request";
  if (p.stock === 0) return "out-of-stock";
  if (p.stock <= 5) return "low-stock";
  return "in-stock";
}

export function availabilityLabel(status) {
  return { "in-stock": "In Stock", "low-stock": "Low Stock", "out-of-stock": "Out of Stock", "on-request": "Price/Stock on Request" }[status];
}

export function priceLabel(p) {
  if (p.wholesalePrice) return `PKR ${p.wholesalePrice.toLocaleString()}`;
  if (p.priceMin && p.priceMax) return `PKR ${p.priceMin.toLocaleString()}–${p.priceMax.toLocaleString()}`;
  return "Price on request";
}

export function brandCount(brand) {
  return PRODUCTS.filter(p => p.brand === brand).length;
}

// ---- State ----
let state = { search: "", brand: "all", availability: "all", ram: "all", storage: "all", sort: "default" };

export function setFilter(key, value) { state[key] = value; renderProducts(); }
export function resetFilters() {
  state = { search: "", brand: "all", availability: "all", ram: "all", storage: "all", sort: "default" };
  const searchInput = document.getElementById("searchInput");
  if (searchInput) searchInput.value = "";
  document.querySelectorAll("#filterRow select").forEach(sel => sel.value = "all");
  renderProducts();
}

function filteredProducts() {
  let list = PRODUCTS.filter(p => {
    if (state.brand !== "all" && p.brand !== state.brand) return false;
    if (state.ram !== "all" && p.ram !== state.ram) return false;
    if (state.storage !== "all" && p.storage !== state.storage) return false;
    if (state.availability !== "all" && availabilityOf(p) !== state.availability) return false;
    if (state.search) {
      const q = state.search.toLowerCase();
      const hay = `${p.brand} ${p.model} ${p.ram} ${p.storage}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  if (state.sort === "price-asc") list.sort((a, b) => (a.wholesalePrice || a.priceMin || 0) - (b.wholesalePrice || b.priceMin || 0));
  if (state.sort === "price-desc") list.sort((a, b) => (b.wholesalePrice || b.priceMin || 0) - (a.wholesalePrice || a.priceMin || 0));
  if (state.sort === "stock-desc") list.sort((a, b) => (b.stock || 0) - (a.stock || 0));
  if (state.sort === "alpha") list.sort((a, b) => `${a.brand}${a.model}`.localeCompare(`${b.brand}${b.model}`));

  return list;
}

export function renderProducts() {
  const grid = document.getElementById("productGrid");
  if (!grid) return;
  const list = filteredProducts();

  if (list.length === 0) {
    grid.innerHTML = `<div class="no-results">No phones match your search. Try a different brand, spec, or clear filters.</div>`;
    return;
  }

  grid.innerHTML = list.map(p => {
    const status = availabilityOf(p);
    return `
    <article class="product-card glass reveal in" data-id="${p.id}" tabindex="0" role="button" aria-label="View ${p.brand} ${p.model} details">
      <div class="product-thumb">
        <img src="${p.image || FALLBACK_IMAGE}" alt="${p.brand} ${p.model}" loading="lazy"
             onerror="this.onerror=null;this.src='${FALLBACK_IMAGE}'">
      </div>
      <div class="product-name">${p.brand} ${p.model}</div>
      <div class="product-specs">${p.ram} / ${p.storage}</div>
      <div class="product-bottom">
        <span class="${p.wholesalePrice || p.priceMin ? 'price' : 'price on-request'}">${priceLabel(p)}</span>
        <span class="badge ${status}">${availabilityLabel(status)}</span>
      </div>
    </article>`;
  }).join("");

  grid.querySelectorAll(".product-card").forEach(card => {
    card.addEventListener("click", () => openProductModal(card.dataset.id));
    card.addEventListener("keypress", (e) => { if (e.key === "Enter") openProductModal(card.dataset.id); });
  });
}

export function populateFilterOptions() {
  const ramSel = document.getElementById("filterRam");
  const storageSel = document.getElementById("filterStorage");
  if (ramSel) {
    const rams = [...new Set(PRODUCTS.map(p => p.ram).filter(r => r && r !== "—"))];
    ramSel.innerHTML = `<option value="all">All RAM</option>` + rams.map(r => `<option value="${r}">${r}</option>`).join("");
  }
  if (storageSel) {
    const storages = [...new Set(PRODUCTS.map(p => p.storage).filter(s => s && s !== "—"))];
    storageSel.innerHTML = `<option value="all">All Storage</option>` + storages.map(s => `<option value="${s}">${s}</option>`).join("");
  }
}

export function renderBrands() {
  const grid = document.getElementById("brandGrid");
  if (!grid) return;
  grid.innerHTML = BRANDS.map(b => `
    <div class="brand-card glass reveal in" data-brand="${b}" tabindex="0" role="button" aria-label="Filter by ${b}">
      <div class="brand-mark">${b}</div>
      <div class="brand-count">${brandCount(b)} model${brandCount(b) === 1 ? "" : "s"}</div>
    </div>`).join("");

  grid.querySelectorAll(".brand-card").forEach(card => {
    card.addEventListener("click", () => {
      grid.querySelectorAll(".brand-card").forEach(c => c.classList.remove("active"));
      card.classList.add("active");
      setFilter("brand", card.dataset.brand);
      document.getElementById("stock")?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });
}

// ---- Product modal ----
function openProductModal(id) {
  const p = PRODUCTS.find(x => x.id === id);
  if (!p) return;
  if (p.detailPage) { window.location.href = p.detailPage; return; }

  const overlay = document.getElementById("productModalOverlay");
  const status = availabilityOf(p);
  document.getElementById("productModalBody").innerHTML = `
    <h3>${p.brand} ${p.model}</h3>
    <div class="modal-spec-row"><span>RAM</span><span>${p.ram}</span></div>
    <div class="modal-spec-row"><span>Storage</span><span>${p.storage}</span></div>
    <div class="modal-spec-row"><span>Wholesale Price</span><span>${priceLabel(p)}</span></div>
    <div class="modal-spec-row"><span>Availability</span><span>${availabilityLabel(status)}</span></div>
    <div class="hero-actions" style="margin-top:20px;">
      <button class="btn btn-primary btn-block" id="modalAddToCart" ${status === "out-of-stock" ? "disabled" : ""}>Add to Cart</button>
    </div>`;
  document.getElementById("modalAddToCart")?.addEventListener("click", () => {
    window.dispatchEvent(new CustomEvent("smobile:add-to-cart", { detail: { id: p.id, qty: 1 } }));
    closeProductModal();
  });
  overlay.classList.add("open");
}
function closeProductModal() { document.getElementById("productModalOverlay")?.classList.remove("open"); }

export function initInventoryUI() {
  populateFilterOptions();
  renderBrands();
  renderProducts();

  const searchInput = document.getElementById("searchInput");
  const searchBox = document.getElementById("searchBox");
  searchInput?.addEventListener("input", (e) => {
    state.search = e.target.value.trim();
    searchBox.classList.toggle("has-text", !!state.search);
    renderProducts();
  });
  document.getElementById("searchClear")?.addEventListener("click", () => {
    searchInput.value = ""; state.search = "";
    searchBox.classList.remove("has-text");
    renderProducts();
  });

  document.getElementById("filterAvailability")?.addEventListener("change", (e) => setFilter("availability", e.target.value));
  document.getElementById("filterRam")?.addEventListener("change", (e) => setFilter("ram", e.target.value));
  document.getElementById("filterStorage")?.addEventListener("change", (e) => setFilter("storage", e.target.value));
  document.getElementById("filterSort")?.addEventListener("change", (e) => setFilter("sort", e.target.value));
  document.getElementById("resetFilters")?.addEventListener("click", () => {
    resetFilters();
    document.querySelectorAll(".brand-card").forEach(c => c.classList.remove("active"));
  });

  document.getElementById("productModalClose")?.addEventListener("click", closeProductModal);
  document.getElementById("productModalOverlay")?.addEventListener("click", (e) => {
    if (e.target.id === "productModalOverlay") closeProductModal();
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeProductModal(); });
}
