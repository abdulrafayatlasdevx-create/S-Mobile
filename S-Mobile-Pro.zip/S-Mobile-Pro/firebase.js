// =========================================================
// FIREBASE.JS — initialization only
// =========================================================
// This file holds PUBLIC Firebase web config (safe to expose client-side —
// Firebase security is enforced by Firestore/Auth rules, not by hiding this).
//
// >>> REPLACE the values below with your real Firebase project config <<<
// Firebase Console → Project settings → General → Your apps → SDK setup & config

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "REPLACE_ME",
  authDomain: "REPLACE_ME.firebaseapp.com",
  projectId: "REPLACE_ME",
  storageBucket: "REPLACE_ME.appspot.com",
  messagingSenderId: "REPLACE_ME",
  appId: "REPLACE_ME"
};

let app, auth, db, firebaseReady = false;

try {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  firebaseReady = firebaseConfig.apiKey !== "REPLACE_ME";
} catch (err) {
  console.error("Firebase failed to initialize:", err);
  firebaseReady = false;
}

export { app, auth, db, firebaseReady };
