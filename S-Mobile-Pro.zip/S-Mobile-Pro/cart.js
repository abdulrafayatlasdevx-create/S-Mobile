// =========================================================
// CART.JS — cart logic, localStorage key: "smobile-cart"
// =========================================================
import { PRODUCTS, FALLBACK_IMAGE, priceLabel, availabilityOf } from "./inventory.js";

const CART_KEY = "smobile-cart";

function readCart() {
  try {
    const raw = localStorage.getItem(CART_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error("Cart read failed, resetting cart.", e);
    return [];
  }
}

function writeCart(cart) {
  try {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
  } catch (e) {
    console.error("Cart save failed (storage may be full or blocked).", e);
  }
  renderCart();
  updateCartBadge();
}

export function addToCart(id, qty = 1) {
  const product = PRODUCTS.find(p => p.id === id);
  if (!product) return;
  if (availabilityOf(product) === "out-of-stock") return;

  const cart = readCart();
  const existing = cart.find(i => i.id === id);
  if (existing) existing.qty += qty;
  else cart.push({ id, qty });
  writeCart(cart);
  openCartDrawer();
}

export function removeFromCart(id) {
  writeCart(readCart().filter(i => i.id !== id));
}

export function changeQty(id, delta) {
  const cart = readCart();
  const item = cart.find(i => i.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) return removeFromCart(id);
  writeCart(cart);
}

export function cartCount() {
  return readCart().reduce((sum, i) => sum + i.qty, 0);
}

export function cartDetails() {
  return readCart().map(i => {
    const product = PRODUCTS.find(p => p.id === i.id);
    return product ? { ...i, product } : null;
  }).filter(Boolean);
}

export function cartSubtotal() {
  return cartDetails().reduce((sum, i) => {
    const unit = i.product.wholesalePrice || i.product.priceMin || 0;
    return sum + unit * i.qty;
  }, 0);
}

export function clearCart() { writeCart([]); }

function updateCartBadge() {
  const badge = document.getElementById("cartBadge");
  if (!badge) return;
  const count = cartCount();
  badge.textContent = count;
  badge.style.display = count > 0 ? "flex" : "none";
}

export function renderCart() {
  const list = document.getElementById("cartItems");
  const subtotalEl = document.getElementById("cartSubtotal");
  if (!list) return;
  const items = cartDetails();

  if (items.length === 0) {
    list.innerHTML = `<div class="cart-empty">Your cart is empty. Browse the stock section to add phones.</div>`;
  } else {
    list.innerHTML = items.map(i => `
      <div class="cart-item" data-id="${i.id}">
        <img class="cart-item-thumb" src="${i.product.image || FALLBACK_IMAGE}" alt="${i.product.brand} ${i.product.model}"
             onerror="this.onerror=null;this.src='${FALLBACK_IMAGE}'">
        <div class="cart-item-info">
          <div class="cart-item-name">${i.product.brand} ${i.product.model}</div>
          <div class="cart-item-meta">${i.product.ram} / ${i.product.storage} · ${priceLabel(i.product)}</div>
          <div class="qty-control">
            <button class="qty-minus" aria-label="Decrease quantity">−</button>
            <span>${i.qty}</span>
            <button class="qty-plus" aria-label="Increase quantity">+</button>
            <button class="qty-remove" aria-label="Remove item" style="margin-left:auto;color:var(--danger);border:none;background:none;">Remove</button>
          </div>
        </div>
      </div>`).join("");

    list.querySelectorAll(".cart-item").forEach(row => {
      const id = row.dataset.id;
      row.querySelector(".qty-plus").addEventListener("click", () => changeQty(id, 1));
      row.querySelector(".qty-minus").addEventListener("click", () => changeQty(id, -1));
      row.querySelector(".qty-remove").addEventListener("click", () => removeFromCart(id));
    });
  }

  if (subtotalEl) {
    const subtotal = cartSubtotal();
    subtotalEl.textContent = subtotal > 0 ? `PKR ${subtotal.toLocaleString()}` : "Contact for quote";
  }
}

export function openCartDrawer() {
  document.getElementById("cartDrawer")?.classList.add("open");
  document.getElementById("cartOverlay")?.classList.add("open");
}
export function closeCartDrawer() {
  document.getElementById("cartDrawer")?.classList.remove("open");
  document.getElementById("cartOverlay")?.classList.remove("open");
}

export function initCartUI() {
  renderCart();
  updateCartBadge();

  document.getElementById("cartToggle")?.addEventListener("click", openCartDrawer);
  document.getElementById("cartClose")?.addEventListener("click", closeCartDrawer);
  document.getElementById("cartOverlay")?.addEventListener("click", closeCartDrawer);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeCartDrawer(); });

  window.addEventListener("smobile:add-to-cart", (e) => addToCart(e.detail.id, e.detail.qty || 1));

  document.getElementById("checkoutBtn")?.addEventListener("click", () => {
    if (cartCount() === 0) return;
    closeCartDrawer();
    document.getElementById("checkout")?.scrollIntoView({ behavior: "smooth" });
  });
}
