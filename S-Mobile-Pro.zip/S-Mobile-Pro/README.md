# S Mobile Pro — Website

## What's here
A full front end + Firebase-ready back end for a mobile-phone wholesale business:
dark/light theme, animated loading screen, sticky glass header with a working
mobile hamburger menu, a CSS-3D hero, brand filtering, search/filter/sort
inventory, a product modal, a persistent cart (`localStorage: smobile-cart`),
an order-request flow, Firebase email/password auth, a user account view, an
admin dashboard (product CRUD, order/user viewing), two full product detail
pages (Vivo X300 FE, Vivo V80 Lite 5G) with variant selectors, SEO tags,
robots.txt/sitemap.xml, and reduced-motion/accessibility support.

## Before you deploy — required steps

### 1. Connect Firebase
1. Create a project at https://console.firebase.google.com
2. Enable **Authentication → Email/Password**
3. Enable **Firestore Database** (start in production mode)
4. Project settings → your web app → copy the config object
5. Paste those values into `firebase.js` (replace every `"REPLACE_ME"`)
6. Firestore → Rules → paste the contents of `firestore.rules` and publish

### 2. Make yourself an admin
1. Sign up on the live site normally (creates a `users/{uid}` doc with `role: "customer"`)
2. In Firestore Console, open that document and change `role` to `"admin"`
3. Log back in — the Admin Dashboard link will now work at `/admin/index.html`

### 3. Fill in missing inventory data
Open `inventory.js`. Every product with `pending: true`, or with
`wholesalePrice: null` / `stock: null`, is a placeholder because that exact
figure wasn't supplied. You can either:
- Edit `inventory.js` directly (fastest for a first launch), or
- Once Firebase is connected, move products into Firestore's `products`
  collection and manage them from the Admin Dashboard instead.

### 4. Add real product images
Products currently show a clean placeholder graphic. Add an `image: "https://..."`
field to any product object once you have real photo URLs — no Storage upload needed.

### 5. Confirm the map pin
The embedded map currently searches for the address text you provided. If you
have the exact Google Maps pin/link for the Shujabad shop, replace the `src`
in the map iframe (in `index.html`, Contact section) with that link.

## Deploying to Netlify
1. Push this folder to a GitHub repo (or drag-and-drop the folder into Netlify)
2. Netlify → Add new site → Deploy. No build command needed — it's static.
3. In Firebase Console → Authentication → Settings → Authorized domains,
   add your Netlify domain (e.g. `smobilepro.netlify.app`) or your custom domain.

## File map
- `index.html` — main site (all customer-facing sections)
- `style.css` — full design system (colors, type, 3D/glass components, responsive rules)
- `script.js` — loader, theme, nav, scroll reveal, parallax, forms
- `firebase.js` / `auth.js` / `cart.js` / `inventory.js` / `admin.js` — logic modules
- `products/` — dedicated flagship product pages
- `admin/index.html` — admin dashboard shell
- `firestore.rules` — the real security boundary (copy into Firebase Console)
- `robots.txt`, `sitemap.xml` — SEO
