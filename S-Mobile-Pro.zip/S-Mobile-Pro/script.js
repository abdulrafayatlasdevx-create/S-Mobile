// =========================================================
// SCRIPT.JS — loading screen, theme, nav, animations, forms
// =========================================================
import { initInventoryUI } from "./inventory.js";
import { initCartUI } from "./cart.js";
import { signUp, logIn, logOut, resetPassword, onAuthChange, getCurrentUser } from "./auth.js";
import { db, firebaseReady } from "./firebase.js";
import { cartDetails, cartSubtotal, clearCart } from "./cart.js";
import { collection, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

// ---------- Loading screen ----------
const loader = document.getElementById("loader");
function hideLoader() {
  loader?.classList.add("hidden");
}
window.addEventListener("load", () => setTimeout(hideLoader, 500));
setTimeout(hideLoader, 4000); // hard fallback — never stay stuck

// ---------- Theme ----------
const THEME_KEY = "smobile-theme";
function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem(THEME_KEY, theme);
  document.querySelectorAll(".theme-icon-dark").forEach(el => el.style.display = theme === "dark" ? "block" : "none");
  document.querySelectorAll(".theme-icon-light").forEach(el => el.style.display = theme === "light" ? "block" : "none");
}
function initTheme() {
  const saved = localStorage.getItem(THEME_KEY);
  const systemPref = window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  applyTheme(saved || systemPref);
  document.getElementById("themeToggle")?.addEventListener("click", () => {
    const current = document.documentElement.getAttribute("data-theme") || "dark";
    applyTheme(current === "dark" ? "light" : "dark");
  });
}

// ---------- Sticky header ----------
function initHeaderScroll() {
  const header = document.querySelector(".site-header");
  if (!header) return;
  const onScroll = () => header.classList.toggle("scrolled", window.scrollY > 20);
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();
}

// ---------- Mobile menu ----------
function initMobileMenu() {
  const menu = document.getElementById("mobileMenu");
  const overlay = document.getElementById("mobileMenuOverlay");
  const openBtn = document.getElementById("hamburgerBtn");
  const closeBtn = document.getElementById("mobileMenuClose");

  const open = () => { menu?.classList.add("open"); overlay?.classList.add("open"); document.body.style.overflow = "hidden"; };
  const close = () => { menu?.classList.remove("open"); overlay?.classList.remove("open"); document.body.style.overflow = ""; };

  openBtn?.addEventListener("click", open);
  closeBtn?.addEventListener("click", close);
  overlay?.addEventListener("click", close);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });
  menu?.querySelectorAll("a").forEach(a => a.addEventListener("click", close));
}

// ---------- Scroll reveal ----------
function initScrollReveal() {
  const items = document.querySelectorAll(".reveal");
  if (!("IntersectionObserver" in window)) { items.forEach(i => i.classList.add("in")); return; }
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add("in"); obs.unobserve(entry.target); } });
  }, { threshold: 0.15 });
  items.forEach(i => obs.observe(i));
}

// ---------- Stat counters ----------
function initCounters() {
  const counters = document.querySelectorAll("[data-count]");
  if (!counters.length) return;
  const animate = (el) => {
    const target = parseInt(el.dataset.count, 10);
    const duration = 1200;
    const start = performance.now();
    function tick(now) {
      const progress = Math.min((now - start) / duration, 1);
      el.textContent = Math.floor(progress * target).toLocaleString();
      if (progress < 1) requestAnimationFrame(tick);
      else el.textContent = target.toLocaleString();
    }
    requestAnimationFrame(tick);
  };
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(entry => { if (entry.isIntersecting) { animate(entry.target); obs.unobserve(entry.target); } });
  }, { threshold: 0.5 });
  counters.forEach(c => obs.observe(c));
}

// ---------- Hero parallax (mouse + touch, reduced-motion aware) ----------
function initHeroParallax() {
  const stage = document.querySelector(".phone-3d");
  if (!stage) return;
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduceMotion) return;

  const handleMove = (x, y, rect) => {
    const relX = (x - rect.left) / rect.width - 0.5;
    const relY = (y - rect.top) / rect.height - 0.5;
    stage.style.transform = `rotateY(${-18 + relX * 20}deg) rotateX(${6 - relY * 14}deg)`;
  };
  const heroStage = document.querySelector(".hero-stage");
  heroStage?.addEventListener("mousemove", (e) => handleMove(e.clientX, e.clientY, heroStage.getBoundingClientRect()));
  heroStage?.addEventListener("mouseleave", () => { stage.style.transform = ""; });
  heroStage?.addEventListener("touchmove", (e) => {
    const t = e.touches[0];
    handleMove(t.clientX, t.clientY, heroStage.getBoundingClientRect());
  }, { passive: true });
}

// ---------- Smooth nav active state ----------
function initNavActive() {
  const links = document.querySelectorAll(".nav-links a, .mobile-menu nav a");
  const sections = [...links].map(l => document.querySelector(l.getAttribute("href"))).filter(Boolean);
  if (!("IntersectionObserver" in window) || !sections.length) return;
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        links.forEach(l => l.classList.toggle("active", l.getAttribute("href") === `#${entry.target.id}`));
      }
    });
  }, { threshold: 0.5 });
  sections.forEach(s => obs.observe(s));
}

// ---------- Auth UI ----------
function initAuthUI() {
  const tabs = document.querySelectorAll(".auth-tabs button");
  const loginForm = document.getElementById("loginForm");
  const signupForm = document.getElementById("signupForm");
  const accountView = document.getElementById("accountView");
  const authForms = document.getElementById("authForms");

  tabs.forEach(tab => tab.addEventListener("click", () => {
    tabs.forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    loginForm.style.display = tab.dataset.tab === "login" ? "block" : "none";
    signupForm.style.display = tab.dataset.tab === "signup" ? "block" : "none";
  }));

  loginForm?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(loginForm);
    const msg = document.getElementById("loginMsg");
    const btn = loginForm.querySelector("button[type=submit]");
    btn.disabled = true; btn.textContent = "Signing in…";
    const res = await logIn(fd.get("email"), fd.get("password"));
    btn.disabled = false; btn.textContent = "Log In";
    showFormMsg(msg, res.ok ? "Welcome back!" : res.error, res.ok);
  });

  signupForm?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(signupForm);
    const msg = document.getElementById("signupMsg");
    const btn = signupForm.querySelector("button[type=submit]");
    btn.disabled = true; btn.textContent = "Creating account…";
    const res = await signUp(fd.get("name"), fd.get("email"), fd.get("password"));
    btn.disabled = false; btn.textContent = "Create Account";
    showFormMsg(msg, res.ok ? "Account created!" : res.error, res.ok);
  });

  document.getElementById("resetPasswordLink")?.addEventListener("click", async (e) => {
    e.preventDefault();
    const email = loginForm.querySelector("[name=email]").value;
    if (!email) return showFormMsg(document.getElementById("loginMsg"), "Enter your email above first.", false);
    const res = await resetPassword(email);
    showFormMsg(document.getElementById("loginMsg"), res.ok ? "Password reset email sent." : res.error, res.ok);
  });

  document.getElementById("logoutBtn")?.addEventListener("click", () => logOut());

  onAuthChange((user) => {
    document.querySelectorAll(".auth-only").forEach(el => el.classList.toggle("hidden", !user));
    document.querySelectorAll(".guest-only").forEach(el => el.classList.toggle("hidden", !!user));
    if (accountView && authForms) {
      accountView.classList.toggle("hidden", !user);
      authForms.classList.toggle("hidden", !!user);
    }
    if (user) {
      const emailEl = document.getElementById("accountEmail");
      if (emailEl) emailEl.textContent = user.email;
    }
  });
}

function showFormMsg(el, text, ok) {
  if (!el) return;
  el.textContent = text;
  el.className = `form-msg show ${ok ? "success" : "error"}`;
}

// ---------- Checkout / order request ----------
function initCheckout() {
  const form = document.getElementById("checkoutForm");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const items = cartDetails();
    const msg = document.getElementById("checkoutMsg");
    if (items.length === 0) return showFormMsg(msg, "Your cart is empty — add a phone first.", false);

    const fd = new FormData(form);
    const name = fd.get("name")?.trim();
    const phone = fd.get("phone")?.trim();
    const email = fd.get("email")?.trim();
    if (!name || !phone) return showFormMsg(msg, "Please provide your name and phone number.", false);

    const btn = form.querySelector("button[type=submit]");
    btn.disabled = true; btn.textContent = "Submitting…";

    const order = {
      items: items.map(i => ({ brand: i.product.brand, model: i.product.model, ram: i.product.ram, storage: i.product.storage, qty: i.qty })),
      subtotal: cartSubtotal(),
      name, phone, email: email || null,
      message: fd.get("message") || "",
      status: "pending",
      userId: getCurrentUser()?.uid || null,
      createdAt: firebaseReady ? serverTimestamp() : new Date().toISOString()
    };

    try {
      if (firebaseReady) {
        await addDoc(collection(db, "orders"), order);
      } else {
        console.warn("Firebase not configured — order captured locally only:", order);
      }
      showFormMsg(msg, "Order request sent! We'll contact you shortly to confirm.", true);
      form.reset();
      clearCart();
    } catch (err) {
      showFormMsg(msg, "Could not submit your order — please try again or contact us on WhatsApp.", false);
    } finally {
      btn.disabled = false; btn.textContent = "Submit Order Request";
    }
  });
}

// ---------- Contact form ----------
function initContactForm() {
  const form = document.getElementById("contactForm");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const msg = document.getElementById("contactMsg");
    const fd = new FormData(form);
    if (!fd.get("name") || !fd.get("message")) return showFormMsg(msg, "Please fill in your name and message.", false);
    const btn = form.querySelector("button[type=submit]");
    btn.disabled = true; btn.textContent = "Sending…";
    try {
      if (firebaseReady) {
        await addDoc(collection(db, "contactMessages"), {
          name: fd.get("name"), email: fd.get("email") || null, message: fd.get("message"),
          createdAt: serverTimestamp()
        });
      }
      showFormMsg(msg, "Message sent — we'll get back to you soon.", true);
      form.reset();
    } catch (err) {
      showFormMsg(msg, "Could not send message — please try WhatsApp instead.", false);
    } finally {
      btn.disabled = false; btn.textContent = "Send Message";
    }
  });
}

// ---------- Init ----------
document.addEventListener("DOMContentLoaded", () => {
  initTheme();
  initHeaderScroll();
  initMobileMenu();
  initScrollReveal();
  initCounters();
  initHeroParallax();
  initNavActive();
  initInventoryUI();
  initCartUI();
  initAuthUI();
  initCheckout();
  initContactForm();
});
