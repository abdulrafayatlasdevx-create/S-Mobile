// =========================================================
// AUTH.JS — Firebase Authentication (email/password)
// =========================================================
import { auth, db, firebaseReady } from "./firebase.js";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {
  doc, setDoc, getDoc, serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

let currentUser = null;
let currentRole = "customer";
const authListeners = [];

function onAuthChange(cb) { authListeners.push(cb); }
function notifyAuthListeners() { authListeners.forEach(cb => cb(currentUser, currentRole)); }

async function signUp(name, email, password) {
  if (!firebaseReady) return { ok: false, error: "Service not configured yet. Please contact us directly." };
  try {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    await setDoc(doc(db, "users", cred.user.uid), {
      uid: cred.user.uid, name, email, role: "customer", createdAt: serverTimestamp()
    });
    return { ok: true };
  } catch (err) {
    return { ok: false, error: friendlyAuthError(err) };
  }
}

async function logIn(email, password) {
  if (!firebaseReady) return { ok: false, error: "Service not configured yet. Please contact us directly." };
  try {
    await signInWithEmailAndPassword(auth, email, password);
    return { ok: true };
  } catch (err) {
    return { ok: false, error: friendlyAuthError(err) };
  }
}

async function logOut() {
  if (!firebaseReady) return;
  await signOut(auth);
}

async function resetPassword(email) {
  if (!firebaseReady) return { ok: false, error: "Service not configured yet." };
  try {
    await sendPasswordResetEmail(auth, email);
    return { ok: true };
  } catch (err) {
    return { ok: false, error: friendlyAuthError(err) };
  }
}

function friendlyAuthError(err) {
  const code = err?.code || "";
  const map = {
    "auth/email-already-in-use": "That email is already registered — try logging in instead.",
    "auth/invalid-email": "Please enter a valid email address.",
    "auth/weak-password": "Password should be at least 6 characters.",
    "auth/user-not-found": "No account found with that email.",
    "auth/wrong-password": "Incorrect password. Try again or reset it.",
    "auth/invalid-credential": "Incorrect email or password.",
    "auth/too-many-requests": "Too many attempts. Please wait a moment and try again."
  };
  return map[code] || "Something went wrong. Please try again.";
}

if (firebaseReady) {
  onAuthStateChanged(auth, async (user) => {
    currentUser = user;
    currentRole = "customer";
    if (user) {
      try {
        const snap = await getDoc(doc(db, "users", user.uid));
        if (snap.exists()) currentRole = snap.data().role || "customer";
      } catch (e) { console.error("Could not load user role:", e); }
    }
    notifyAuthListeners();
  });
} else {
  // No Firebase config yet — treat as logged out, but don't break the page.
  setTimeout(notifyAuthListeners, 0);
}

export function getCurrentUser() { return currentUser; }
export function getCurrentRole() { return currentRole; }
export { signUp, logIn, logOut, resetPassword, onAuthChange };
