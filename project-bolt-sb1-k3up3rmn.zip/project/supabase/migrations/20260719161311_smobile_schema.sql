/*
# S Mobile ecommerce schema

1. New Tables
- brands, categories, products, reviews, offers, homepage_sections, x300fe_specs, settings, profiles, carts, wishlists, orders, order_items, notifications
2. Security
- RLS enabled on every table. Public read on catalog; owner-scoped CRUD on user data.
- Authenticated can manage catalog (admin demo). Tighten to service role in production.
*/

CREATE TABLE IF NOT EXISTS brands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  logo_url text,
  country text,
  featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  icon text,
  created_at timestamptz DEFAULT now()
);
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  brand_id uuid REFERENCES brands(id) ON DELETE SET NULL,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  short_description text,
  description text,
  price numeric NOT NULL DEFAULT 0,
  compare_price numeric,
  images text[] DEFAULT '{}',
  stock int NOT NULL DEFAULT 0,
  rating numeric DEFAULT 0,
  reviews_count int DEFAULT 0,
  is_featured boolean DEFAULT false,
  is_published boolean DEFAULT true,
  launch_date timestamptz,
  tags text[] DEFAULT '{}',
  variants jsonb DEFAULT '{}'::jsonb,
  specs jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS products_category_idx ON products(category_id);
CREATE INDEX IF NOT EXISTS products_brand_idx ON products(brand_id);
CREATE INDEX IF NOT EXISTS products_slug_idx ON products(slug);

CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  user_id uuid,
  author_name text,
  rating int NOT NULL DEFAULT 5,
  title text,
  body text,
  approved boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS reviews_product_idx ON reviews(product_id);

CREATE TABLE IF NOT EXISTS offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  subtitle text,
  image_url text,
  badge text,
  cta_text text,
  cta_link text,
  active boolean DEFAULT true,
  sort_order int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
CREATE TABLE IF NOT EXISTS homepage_sections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  section_key text UNIQUE NOT NULL,
  title text,
  subtitle text,
  enabled boolean DEFAULT true,
  sort_order int DEFAULT 0,
  config jsonb DEFAULT '{}'::jsonb,
  updated_at timestamptz DEFAULT now()
);
CREATE TABLE IF NOT EXISTS x300fe_specs (
  id int PRIMARY KEY DEFAULT 1,
  price numeric DEFAULT 269999,
  status text DEFAULT 'Available Now',
  launch_date timestamptz,
  colors jsonb DEFAULT '["Green","White","Black"]'::jsonb,
  platform jsonb DEFAULT '{}'::jsonb,
  memory jsonb DEFAULT '{}'::jsonb,
  battery jsonb DEFAULT '{}'::jsonb,
  design jsonb DEFAULT '{}'::jsonb,
  display jsonb DEFAULT '{}'::jsonb,
  camera jsonb DEFAULT '{}'::jsonb,
  connectivity jsonb DEFAULT '{}'::jsonb,
  sensors jsonb DEFAULT '{}'::jsonb,
  box_contents jsonb DEFAULT '[]'::jsonb,
  warranty text,
  faqs jsonb DEFAULT '[]'::jsonb,
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT x300_single_row CHECK (id = 1)
);
INSERT INTO x300fe_specs (id) VALUES (1) ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS settings (
  id int PRIMARY KEY DEFAULT 1,
  store_name text DEFAULT 'S Mobile',
  accent_primary text DEFAULT '#00C8FF',
  accent_secondary text DEFAULT '#7B61FF',
  contact_phone1 text DEFAULT '0301-7504004',
  contact_phone2 text DEFAULT '0339-7504004',
  contact_phone3 text DEFAULT '0300-7336860',
  address text DEFAULT 'Shop No. 1/2, S Mobile, Usman Plaza, Jalalpur Rd, Near Hafiz Barfi, Shujaabad 59220, Pakistan',
  whatsapp text DEFAULT '923017504004',
  theme_switch_enabled boolean DEFAULT true,
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT settings_single_row CHECK (id = 1)
);
INSERT INTO settings (id) VALUES (1) ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  phone text,
  role text NOT NULL DEFAULT 'customer',
  created_at timestamptz DEFAULT now()
);
CREATE TABLE IF NOT EXISTS carts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  updated_at timestamptz DEFAULT now()
);
CREATE TABLE IF NOT EXISTS wishlists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE (user_id, product_id)
);
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'Pending',
  total numeric NOT NULL DEFAULT 0,
  shipping_address jsonb DEFAULT '{}'::jsonb,
  payment_method text DEFAULT 'COD',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS orders_user_idx ON orders(user_id);
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  name text,
  image_url text,
  variant jsonb DEFAULT '{}'::jsonb,
  price numeric NOT NULL DEFAULT 0,
  quantity int NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS order_items_order_idx ON order_items(order_id);
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  body text,
  type text,
  read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE brands ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE offers ENABLE ROW LEVEL SECURITY;
ALTER TABLE homepage_sections ENABLE ROW LEVEL SECURITY;
ALTER TABLE x300fe_specs ENABLE ROW LEVEL SECURITY;
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE carts ENABLE ROW LEVEL SECURITY;
ALTER TABLE wishlists ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Public catalog reads
DROP POLICY IF EXISTS "catalog_read" ON brands;
CREATE POLICY "catalog_read" ON brands FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "catalog_read" ON categories;
CREATE POLICY "catalog_read" ON categories FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "catalog_read" ON products;
CREATE POLICY "catalog_read" ON products FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "catalog_read" ON offers;
CREATE POLICY "catalog_read" ON offers FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "catalog_read" ON homepage_sections;
CREATE POLICY "catalog_read" ON homepage_sections FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "catalog_read" ON x300fe_specs;
CREATE POLICY "catalog_read" ON x300fe_specs FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "catalog_read" ON settings;
CREATE POLICY "catalog_read" ON settings FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "reviews_read" ON reviews;
CREATE POLICY "reviews_read" ON reviews FOR SELECT TO anon, authenticated USING (true);

-- Catalog management (authenticated, demo admin)
DROP POLICY IF EXISTS "catalog_write" ON brands;
CREATE POLICY "catalog_write" ON brands FOR ALL TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "catalog_write" ON categories;
CREATE POLICY "catalog_write" ON categories FOR ALL TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "catalog_write" ON products;
CREATE POLICY "catalog_write" ON products FOR ALL TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "catalog_write" ON offers;
CREATE POLICY "catalog_write" ON offers FOR ALL TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "catalog_write" ON homepage_sections;
CREATE POLICY "catalog_write" ON homepage_sections FOR ALL TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "catalog_write" ON x300fe_specs;
CREATE POLICY "catalog_write" ON x300fe_specs FOR ALL TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "catalog_write" ON settings;
CREATE POLICY "catalog_write" ON settings FOR ALL TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "reviews_write" ON reviews;
CREATE POLICY "reviews_write" ON reviews FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "reviews_update" ON reviews;
CREATE POLICY "reviews_update" ON reviews FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- Profiles
DROP POLICY IF EXISTS "profiles_read_own" ON profiles;
CREATE POLICY "profiles_read_own" ON profiles FOR SELECT TO authenticated USING (auth.uid() = id);
DROP POLICY IF EXISTS "profiles_write_own" ON profiles;
CREATE POLICY "profiles_write_own" ON profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
DROP POLICY IF EXISTS "profiles_read_all" ON profiles;
CREATE POLICY "profiles_read_all" ON profiles FOR SELECT TO authenticated USING (true);

-- Carts
DROP POLICY IF EXISTS "carts_own" ON carts;
CREATE POLICY "carts_own" ON carts FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "carts_ins" ON carts;
CREATE POLICY "carts_ins" ON carts FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "carts_upd" ON carts;
CREATE POLICY "carts_upd" ON carts FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "carts_del" ON carts;
CREATE POLICY "carts_del" ON carts FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Wishlists
DROP POLICY IF EXISTS "wl_read" ON wishlists;
CREATE POLICY "wl_read" ON wishlists FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "wl_ins" ON wishlists;
CREATE POLICY "wl_ins" ON wishlists FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "wl_del" ON wishlists;
CREATE POLICY "wl_del" ON wishlists FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Orders
DROP POLICY IF EXISTS "orders_read" ON orders;
CREATE POLICY "orders_read" ON orders FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "orders_ins" ON orders;
CREATE POLICY "orders_ins" ON orders FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "orders_upd" ON orders;
CREATE POLICY "orders_upd" ON orders FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Order items
DROP POLICY IF EXISTS "oi_read" ON order_items;
CREATE POLICY "oi_read" ON order_items FOR SELECT TO authenticated USING (
  EXISTS (SELECT 1 FROM orders WHERE orders.id = order_items.order_id AND orders.user_id = auth.uid())
);
DROP POLICY IF EXISTS "oi_ins" ON order_items;
CREATE POLICY "oi_ins" ON order_items FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM orders WHERE orders.id = order_items.order_id AND orders.user_id = auth.uid())
);

-- Notifications
DROP POLICY IF EXISTS "notif_read" ON notifications;
CREATE POLICY "notif_read" ON notifications FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "notif_ins" ON notifications;
CREATE POLICY "notif_ins" ON notifications FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "notif_upd" ON notifications;
CREATE POLICY "notif_upd" ON notifications FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "notif_del" ON notifications;
CREATE POLICY "notif_del" ON notifications FOR DELETE TO authenticated USING (auth.uid() = user_id);
