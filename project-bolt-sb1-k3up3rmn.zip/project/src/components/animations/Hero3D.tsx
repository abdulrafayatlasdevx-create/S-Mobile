import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Environment, ContactShadows, MeshDistortMaterial } from '@react-three/drei';
import { useRef, Suspense } from 'react';
import type { Mesh, Group } from 'three';

function Phone() {
  const group = useRef<Group>(null);
  const screen = useRef<Mesh>(null);

  useFrame((state, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * 0.4;
      const t = state.clock.elapsedTime;
      group.current.position.y = Math.sin(t * 1.2) * 0.08;
    }
  });

  return (
    <group ref={group} rotation={[0.2, 0.4, 0]} scale={1.4}>
      {/* Phone body */}
      <mesh castShadow>
        <boxGeometry args={[1.1, 2.2, 0.12]} />
        <meshStandardMaterial
          color="#0B1120"
          metalness={0.9}
          roughness={0.25}
          envMapIntensity={1.2}
        />
      </mesh>
      {/* Screen */}
      <mesh ref={screen} position={[0, 0, 0.065]}>
        <planeGeometry args={[0.98, 2.05]} />
        <MeshDistortMaterial
          color="#00C8FF"
          emissive="#7B61FF"
          emissiveIntensity={0.6}
          distort={0.25}
          speed={2}
          metalness={0.4}
          roughness={0.1}
        />
      </mesh>
      {/* Camera bump */}
      <mesh position={[-0.28, 0.7, 0.07]}>
        <circleGeometry args={[0.12, 32]} />
        <meshStandardMaterial color="#050816" metalness={0.7} roughness={0.3} />
      </mesh>
      <mesh position={[0.02, 0.7, 0.075]}>
        <circleGeometry args={[0.08, 32]} />
        <meshStandardMaterial color="#1E293B" metalness={0.8} roughness={0.2} />
      </mesh>
      <mesh position={[-0.28, 0.45, 0.07]}>
        <circleGeometry args={[0.1, 32]} />
        <meshStandardMaterial color="#050816" metalness={0.7} roughness={0.3} />
      </mesh>
    </group>
  );
}

function Particles() {
  const ref = useRef<Group>(null);
  useFrame((_, delta) => {
    if (ref.current) ref.current.rotation.y += delta * 0.05;
  });
  const positions: [number, number, number][] = [];
  for (let i = 0; i < 40; i++) {
    positions.push([
      (Math.random() - 0.5) * 8,
      (Math.random() - 0.5) * 6,
      (Math.random() - 0.5) * 4 - 2,
    ]);
  }
  return (
    <group ref={ref}>
      {positions.map((p, i) => (
        <mesh key={i} position={p}>
          <sphereGeometry args={[0.02 + Math.random() * 0.04, 8, 8]} />
          <meshStandardMaterial
            color={i % 2 ? '#00C8FF' : '#7B61FF'}
            emissive={i % 2 ? '#00C8FF' : '#7B61FF'}
            emissiveIntensity={1.5}
          />
        </mesh>
      ))}
    </group>
  );
}

export default function Hero3D() {
  return (
    <Canvas
      camera={{ position: [0, 0, 5], fov: 45 }}
      dpr={[1, 2]}
      gl={{ antialias: true, alpha: true }}
    >
      <ambientLight intensity={0.4} />
      <spotLight
        position={[5, 5, 5]}
        angle={0.3}
        penumbra={1}
        intensity={2}
        color="#00C8FF"
        castShadow
      />
      <spotLight
        position={[-5, -3, 4]}
        angle={0.4}
        penumbra={1}
        intensity={1.5}
        color="#7B61FF"
      />
      <Suspense fallback={null}>
        <Float speed={1.5} rotationIntensity={0.3} floatIntensity={0.6}>
          <Phone />
        </Float>
        <Particles />
        <Environment preset="city" />
        <ContactShadows
          position={[0, -1.8, 0]}
          opacity={0.4}
          scale={6}
          blur={2.5}
          color="#7B61FF"
        />
      </Suspense>
    </Canvas>
  );
}
