import { AnimatePresence, motion } from 'framer-motion';
import { Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../../store/cart';
import { formatPKR } from '../../lib/utils';

export default function CartDrawer() {
  const { items, open, setOpen, remove, setQty, total, count } = useCart();

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setOpen(false)}
            className="fixed inset-0 z-[150] bg-black/60 backdrop-blur-sm"
          />
          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 32 }}
            className="fixed top-0 right-0 bottom-0 z-[160] w-full max-w-md glass-strong flex flex-col"
          >
            <div className="flex items-center justify-between p-5 border-b border-white/10">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-accent-cyan" />
                <span className="font-display font-semibold text-lg">
                  Cart ({count})
                </span>
              </div>
              <button
                onClick={() => setOpen(false)}
                className="w-10 h-10 rounded-full hover:bg-white/10 grid place-items-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {items.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center gap-3 text-slate-400">
                  <ShoppingBag className="w-12 h-12 opacity-40" />
                  <p>Your cart is empty.</p>
                  <Link
                    to="/products"
                    onClick={() => setOpen(false)}
                    className="text-accent-cyan hover:underline text-sm"
                  >
                    Browse products
                  </Link>
                </div>
              ) : (
                items.map((item) => (
                  <motion.div
                    key={item.product_id + JSON.stringify(item.variant)}
                    layout
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="flex gap-3 glass rounded-xl p-3"
                  >
                    <Link
                      to={`/products/${item.slug}`}
                      onClick={() => setOpen(false)}
                      className="w-20 h-20 rounded-lg overflow-hidden shrink-0"
                    >
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </Link>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm line-clamp-2">{item.name}</p>
                      {item.variant?.color && (
                        <p className="text-xs text-slate-400 mt-0.5">
                          {item.variant.color}
                          {item.variant.storage ? ` · ${item.variant.storage}` : ''}
                        </p>
                      )}
                      <p className="text-sm font-semibold mt-1">
                        {formatPKR(item.price)}
                      </p>
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() =>
                              setQty(item.product_id, item.quantity - 1)
                            }
                            className="w-7 h-7 rounded-full glass grid place-items-center hover:bg-white/10"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-sm w-6 text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() =>
                              setQty(item.product_id, item.quantity + 1)
                            }
                            className="w-7 h-7 rounded-full glass grid place-items-center hover:bg-white/10"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        <button
                          onClick={() => remove(item.product_id)}
                          className="text-rose-400 hover:text-rose-300"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </div>

            {items.length > 0 && (
              <div className="p-5 border-t border-white/10 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 text-sm">Subtotal</span>
                  <span className="text-2xl font-bold font-display">
                    {formatPKR(total)}
                  </span>
                </div>
                <Link
                  to="/checkout"
                  onClick={() => setOpen(false)}
                  className="block text-center py-3.5 rounded-full bg-gradient-to-r from-accent-cyan to-accent-purple text-ink-950 font-semibold"
                >
                  Checkout
                </Link>
              </div>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
