import { motion, type HTMLMotionProps } from 'framer-motion';
import { useRef, type ReactNode } from 'react';
import { classNames } from '../../lib/utils';

interface Props extends HTMLMotionProps<'button'> {
  children: ReactNode;
  variant?: 'primary' | 'ghost' | 'outline';
  size?: 'sm' | 'md' | 'lg';
}

export default function MagneticButton({
  children,
  variant = 'primary',
  size = 'md',
  className,
  ...rest
}: Props) {
  const ref = useRef<HTMLButtonElement>(null);

  const handleMove = (e: React.MouseEvent) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const x = e.clientX - (r.left + r.width / 2);
    const y = e.clientY - (r.top + r.height / 2);
    el.style.transform = `translate(${x * 0.18}px, ${y * 0.3}px)`;
  };
  const handleLeave = () => {
    const el = ref.current;
    if (el) el.style.transform = 'translate(0,0)';
  };

  const sizes = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3 text-sm',
    lg: 'px-8 py-4 text-base',
  }[size];

  const variants = {
    primary:
      'bg-gradient-to-r from-accent-cyan to-accent-purple text-ink-950 font-semibold shadow-glow',
    ghost: 'text-slate-200 hover:text-white hover:bg-white/10',
    outline:
      'border border-white/15 text-slate-100 hover:border-accent-cyan hover:text-accent-cyan',
  }[variant];

  return (
    <motion.button
      ref={ref}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      whileTap={{ scale: 0.96 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      className={classNames(
        'relative inline-flex items-center justify-center gap-2 rounded-full transition-colors duration-300 overflow-hidden',
        sizes,
        variants,
        className
      )}
      {...rest}
    >
      {children}
    </motion.button>
  );
}
