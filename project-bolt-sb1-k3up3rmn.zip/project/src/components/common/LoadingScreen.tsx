import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

export default function LoadingScreen() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const t = setInterval(() => {
      setProgress((p) => (p >= 100 ? 100 : p + Math.random() * 12));
    }, 90);
    return () => clearInterval(t);
  }, []);

  return (
    <motion.div
      className="fixed inset-0 z-[300] bg-ink-950 flex flex-col items-center justify-center"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="relative">
        <motion.div
          className="w-20 h-20 rounded-2xl bg-gradient-to-br from-accent-cyan to-accent-purple"
          animate={{ rotate: [0, 360], scale: [1, 1.1, 1] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        />
        <div className="absolute inset-0 blur-2xl bg-gradient-to-br from-accent-cyan to-accent-purple opacity-50" />
      </div>
      <motion.h1
        className="mt-8 text-3xl font-display font-bold tracking-tight"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        S <span className="text-gradient">Mobile</span>
      </motion.h1>
      <div className="mt-6 w-56 h-1 rounded-full bg-white/10 overflow-hidden">
        <motion.div
          className="h-full bg-gradient-to-r from-accent-cyan to-accent-purple"
          style={{ width: `${Math.min(progress, 100)}%` }}
        />
      </div>
      <p className="mt-3 text-xs text-slate-400 tracking-widest uppercase">
        Cinematic Experience
      </p>
    </motion.div>
  );
}
