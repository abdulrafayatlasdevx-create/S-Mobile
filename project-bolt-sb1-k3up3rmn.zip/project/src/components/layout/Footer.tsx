import { Link } from 'react-router-dom';
import { Mail, MapPin, Phone, MessageCircle } from 'lucide-react';
import { useSettings } from '../../lib/hooks';

export default function Footer() {
  const settings = useSettings();
  const year = new Date().getFullYear();

  return (
    <footer className="relative mt-24 border-t border-white/10 bg-ink-900/60">
      <div className="max-w-7xl mx-auto px-6 py-16 grid grid-cols-1 md:grid-cols-4 gap-10">
        <div className="md:col-span-1">
          <Link to="/" className="flex items-center gap-2 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent-cyan to-accent-purple grid place-items-center text-ink-950 font-bold">
              S
            </div>
            <span className="font-display font-bold text-xl">
              S <span className="text-gradient">Mobile</span>
            </span>
          </Link>
          <p className="text-sm text-slate-400 leading-relaxed">
            Premium mobile shopping experience since 2004. Shujaabad, Pakistan.
          </p>
          <div className="flex gap-3 mt-5">
            <a
              href={`https://wa.me/${settings?.whatsapp || '923017504004'}`}
              target="_blank"
              rel="noreferrer"
              className="w-10 h-10 rounded-full glass grid place-items-center hover:text-accent-cyan"
              aria-label="WhatsApp"
            >
              <MessageCircle className="w-4 h-4" />
            </a>
            <a
              href="https://maps.google.com/?q=Shujaabad+Pakistan"
              target="_blank"
              rel="noreferrer"
              className="w-10 h-10 rounded-full glass grid place-items-center hover:text-accent-cyan"
              aria-label="Map"
            >
              <MapPin className="w-4 h-4" />
            </a>
          </div>
        </div>

        <div>
          <h4 className="font-semibold mb-4 text-sm uppercase tracking-widest text-accent-cyan">
            Shop
          </h4>
          <ul className="space-y-2 text-sm text-slate-400">
            <li>
              <Link to="/products" className="hover:text-white">
                All Products
              </Link>
            </li>
            <li>
              <Link to="/products?category=smartphones" className="hover:text-white">
                Smartphones
              </Link>
            </li>
            <li>
              <Link to="/products?category=earbuds" className="hover:text-white">
                Earbuds
              </Link>
            </li>
            <li>
              <Link to="/products/x300-fe" className="hover:text-white">
                vivo X300 FE
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold mb-4 text-sm uppercase tracking-widest text-accent-cyan">
            Company
          </h4>
          <ul className="space-y-2 text-sm text-slate-400">
            <li>
              <Link to="/about" className="hover:text-white">
                About Us
              </Link>
            </li>
            <li>
              <Link to="/contact" className="hover:text-white">
                Contact
              </Link>
            </li>
            <li>
              <Link to="/account" className="hover:text-white">
                My Account
              </Link>
            </li>
            <li>
              <Link to="/admin" className="hover:text-white">
                Admin
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold mb-4 text-sm uppercase tracking-widest text-accent-cyan">
            Contact
          </h4>
          <ul className="space-y-3 text-sm text-slate-400">
            <li className="flex items-start gap-2">
              <MapPin className="w-4 h-4 mt-0.5 text-accent-cyan shrink-0" />
              <span>{settings?.address}</span>
            </li>
            <li className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-accent-cyan" />
              <span>{settings?.contact_phone1}</span>
            </li>
            <li className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-accent-cyan" />
              <span>{settings?.contact_phone2}</span>
            </li>
            <li className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-accent-cyan" />
              <span>{settings?.contact_phone3}</span>
            </li>
            <li className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-accent-cyan" />
              <span>info@smobile.pk</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10 py-6">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <p>
            © {year} S Mobile. Established 2004. Owners: Sajid Qureshi & Shakeel
            Qureshi.
          </p>
          <p>Cinematic 4D experience built with React, Three.js & Supabase.</p>
        </div>
      </div>
    </footer>
  );
}
