import { Link, NavLink, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Menu,
  Moon,
  Search,
  ShoppingBag,
  Sun,
  User,
  X,
  Heart,
  ChevronDown,
  Smartphone,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { useCart } from '../../store/cart';
import { useWishlist } from '../../store/wishlist';
import { useAuth } from '../../store/auth';
import { useTheme } from '../../store/theme';
import { useBrands, useCategories } from '../../lib/hooks';
import { classNames } from '../../lib/utils';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [megaOpen, setMegaOpen] = useState(false);
  const [query, setQuery] = useState('');
  const { count, setOpen: setCartOpen } = useCart();
  const { count: wishCount } = useWishlist();
  const { user } = useAuth();
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();
  const brands = useBrands();
  const categories = useCategories();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/products?search=${encodeURIComponent(query.trim())}`);
      setSearchOpen(false);
      setQuery('');
    }
  };

  const navLinkClass = ({ isActive }: { isActive: boolean }) =>
    classNames(
      'relative text-sm font-medium transition-colors',
      isActive ? 'text-accent-cyan' : 'text-slate-200 hover:text-white'
    );

  return (
    <>
      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 200, damping: 26 }}
        className={classNames(
          'fixed top-0 inset-x-0 z-[100] transition-all duration-500',
          scrolled ? 'glass-strong shadow-card' : 'bg-transparent'
        )}
      >
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <motion.div
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.6 }}
              className="w-9 h-9 rounded-xl bg-gradient-to-br from-accent-cyan to-accent-purple grid place-items-center text-ink-950 font-bold"
            >
              S
            </motion.div>
            <span className="font-display font-bold text-lg tracking-tight">
              S <span className="text-gradient">Mobile</span>
            </span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden lg:flex items-center gap-7">
            <NavLink to="/" className={navLinkClass} end>
              Home
            </NavLink>
            <div
              className="relative"
              onMouseEnter={() => setMegaOpen(true)}
              onMouseLeave={() => setMegaOpen(false)}
            >
              <button className="flex items-center gap-1 text-sm font-medium text-slate-200 hover:text-white">
                Products <ChevronDown className="w-3.5 h-3.5" />
              </button>
              <AnimatePresence>
                {megaOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    transition={{ duration: 0.2 }}
                    className="absolute left-1/2 -translate-x-1/2 top-full mt-3 w-[640px] glass-strong rounded-2xl p-6 grid grid-cols-2 gap-6 shadow-card"
                  >
                    <div>
                      <p className="text-[11px] uppercase tracking-widest text-accent-cyan mb-3">
                        Categories
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        {categories.map((c) => (
                          <Link
                            key={c.id}
                            to={`/products?category=${c.slug}`}
                            className="text-sm text-slate-300 hover:text-accent-cyan transition-colors flex items-center gap-2"
                          >
                            <Smartphone className="w-3.5 h-3.5 opacity-60" />
                            {c.name}
                          </Link>
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="text-[11px] uppercase tracking-widest text-accent-cyan mb-3">
                        Brands
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        {brands.slice(0, 10).map((b) => (
                          <Link
                            key={b.id}
                            to={`/products?brand=${b.slug}`}
                            className="text-sm text-slate-300 hover:text-accent-cyan transition-colors"
                          >
                            {b.name}
                          </Link>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            <NavLink to="/products/x300-fe" className={navLinkClass}>
              X300 FE
            </NavLink>
            <NavLink to="/about" className={navLinkClass}>
              About
            </NavLink>
            <NavLink to="/contact" className={navLinkClass}>
              Contact
            </NavLink>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setSearchOpen((v) => !v)}
              className="w-10 h-10 rounded-full hover:bg-white/10 grid place-items-center"
              aria-label="Search"
            >
              <Search className="w-5 h-5" />
            </button>
            <button
              onClick={toggle}
              className="w-10 h-10 rounded-full hover:bg-white/10 grid place-items-center"
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5" />
              ) : (
                <Moon className="w-5 h-5" />
              )}
            </button>
            <Link
              to="/account?tab=wishlist"
              className="w-10 h-10 rounded-full hover:bg-white/10 grid place-items-center relative"
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] grid place-items-center">
                  {wishCount}
                </span>
              )}
            </Link>
            <button
              onClick={() => setCartOpen(true)}
              className="w-10 h-10 rounded-full hover:bg-white/10 grid place-items-center relative"
              aria-label="Cart"
            >
              <ShoppingBag className="w-5 h-5" />
              {count > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-gradient-to-br from-accent-cyan to-accent-purple text-ink-950 text-[10px] font-bold grid place-items-center">
                  {count}
                </span>
              )}
            </button>
            <Link
              to={user ? '/account' : '/login'}
              className="w-10 h-10 rounded-full hover:bg-white/10 grid place-items-center"
              aria-label="Account"
            >
              <User className="w-5 h-5" />
            </Link>
            <button
              onClick={() => setMobileOpen(true)}
              className="lg:hidden w-10 h-10 rounded-full hover:bg-white/10 grid place-items-center"
              aria-label="Menu"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </nav>

        {/* Search bar */}
        <AnimatePresence>
          {searchOpen && (
            <motion.form
              onSubmit={submitSearch}
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden border-t border-white/10"
            >
              <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-3">
                <Search className="w-5 h-5 text-accent-cyan" />
                <input
                  autoFocus
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search smartphones, brands, accessories..."
                  className="flex-1 bg-transparent outline-none text-lg placeholder:text-slate-500"
                />
                <button
                  type="button"
                  onClick={() => setSearchOpen(false)}
                  className="w-8 h-8 rounded-full hover:bg-white/10 grid place-items-center"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </motion.form>
          )}
        </AnimatePresence>
      </motion.header>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileOpen(false)}
              className="fixed inset-0 z-[110] bg-black/60 backdrop-blur-sm lg:hidden"
            />
            <motion.aside
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', stiffness: 300, damping: 32 }}
              className="fixed top-0 right-0 bottom-0 z-[120] w-[84%] max-w-sm glass-strong p-6 lg:hidden overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-8">
                <span className="font-display font-bold text-xl">
                  S <span className="text-gradient">Mobile</span>
                </span>
                <button
                  onClick={() => setMobileOpen(false)}
                  className="w-10 h-10 rounded-full hover:bg-white/10 grid place-items-center"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex flex-col gap-1">
                {[
                  ['/', 'Home'],
                  ['/products', 'Products'],
                  ['/products/x300-fe', 'X300 FE'],
                  ['/about', 'About'],
                  ['/contact', 'Contact'],
                  [user ? '/account' : '/login', user ? 'Account' : 'Sign In'],
                  ['/admin', 'Admin'],
                ].map(([to, label]) => (
                  <NavLink
                    key={to}
                    to={to}
                    onClick={() => setMobileOpen(false)}
                    className={({ isActive }) =>
                      classNames(
                        'px-4 py-3 rounded-xl text-base font-medium transition-colors',
                        isActive
                          ? 'bg-white/10 text-accent-cyan'
                          : 'text-slate-200 hover:bg-white/5'
                      )
                    }
                  >
                    {label}
                  </NavLink>
                ))}
              </div>
              <div className="mt-8">
                <p className="text-[11px] uppercase tracking-widest text-accent-cyan mb-3">
                  Categories
                </p>
                <div className="flex flex-col gap-1">
                  {categories.map((c) => (
                    <Link
                      key={c.id}
                      to={`/products?category=${c.slug}`}
                      onClick={() => setMobileOpen(false)}
                      className="px-4 py-2 text-sm text-slate-300 hover:text-accent-cyan"
                    >
                      {c.name}
                    </Link>
                  ))}
                </div>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
