import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, ShoppingCart, Eye, Share2, Check } from 'lucide-react';
import type { Product } from '../../lib/types';
import { formatPKR, discountPercent, classNames, share } from '../../lib/utils';
import { useCart } from '../../store/cart';
import { useWishlist } from '../../store/wishlist';
import { useToast } from '../../store/toast';

export default function ProductCard({ product }: { product: Product }) {
  const { add, setOpen } = useCart();
  const { has, toggle } = useWishlist();
  const { push } = useToast();
  const inWishlist = has(product.id);
  const discount = discountPercent(product.price, product.compare_price);
  const outOfStock = product.stock <= 0;
  const brandName = (product as unknown as { brands?: { name: string } }).brands?.name;

  const handleAdd = () => {
    add({
      product_id: product.id,
      name: product.name,
      slug: product.slug,
      image: product.images[0] || '',
      price: product.price,
      quantity: 1,
      variant: product.variants.colors
        ? { color: product.variants.colors[0] }
        : undefined,
    });
    push(`${product.name} added to cart`);
    setOpen(true);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ type: 'spring', stiffness: 200, damping: 24 }}
      whileHover={{ y: -8 }}
      className="group relative glass rounded-2xl overflow-hidden flex flex-col"
    >
      <div className="relative aspect-[4/5] overflow-hidden">
        <Link to={`/products/${product.slug}`}>
          <motion.img
            src={product.images[0]}
            alt={product.name}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
        </Link>
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5">
          {discount && (
            <span className="px-2.5 py-1 rounded-full bg-gradient-to-r from-accent-cyan to-accent-purple text-ink-950 text-xs font-bold">
              -{discount}%
            </span>
          )}
          {product.is_featured && (
            <span className="px-2.5 py-1 rounded-full glass text-[10px] font-semibold uppercase tracking-wider">
              Featured
            </span>
          )}
          {outOfStock ? (
            <span className="px-2.5 py-1 rounded-full bg-rose-500/80 text-white text-[10px] font-semibold uppercase">
              Out of stock
            </span>
          ) : (
            <span className="px-2.5 py-1 rounded-full bg-emerald-500/80 text-white text-[10px] font-semibold uppercase">
              In stock
            </span>
          )}
        </div>
        {/* Quick actions */}
        <div className="absolute top-3 right-3 flex flex-col gap-2">
          <button
            onClick={() => {
              toggle(product.id);
              push(inWishlist ? 'Removed from wishlist' : 'Added to wishlist');
            }}
            className={classNames(
              'w-9 h-9 rounded-full glass grid place-items-center transition-colors',
              inWishlist ? 'text-rose-400' : 'text-slate-200'
            )}
            aria-label="Toggle wishlist"
          >
            {inWishlist ? <Check className="w-4 h-4" /> : <Heart className="w-4 h-4" />}
          </button>
          <button
            onClick={() => share(product.name, window.location.href)}
            className="w-9 h-9 rounded-full glass grid place-items-center text-slate-200 hover:text-accent-cyan"
            aria-label="Share"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>
        {/* Hover quick view */}
        <Link
          to={`/products/${product.slug}`}
          className="absolute inset-x-3 bottom-3 glass-strong rounded-xl py-2.5 flex items-center justify-center gap-2 text-sm font-medium opacity-0 translate-y-3 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300"
        >
          <Eye className="w-4 h-4" /> Quick View
        </Link>
      </div>

      <div className="p-4 flex flex-col gap-2 flex-1">
        {brandName && (
          <span className="text-[11px] uppercase tracking-widest text-accent-cyan/80">
            {brandName}
          </span>
        )}
        <Link to={`/products/${product.slug}`}>
          <h3 className="font-display font-semibold text-base leading-snug line-clamp-2 hover:text-gradient">
            {product.name}
          </h3>
        </Link>
        {product.short_description && (
          <p className="text-xs text-slate-400 line-clamp-2">
            {product.short_description}
          </p>
        )}
        {/* Variants */}
        {product.variants.colors && (
          <div className="flex gap-1.5 mt-1">
            {product.variants.colors.slice(0, 4).map((c) => (
              <span
                key={c}
                className="text-[10px] px-2 py-0.5 rounded-full border border-white/10 text-slate-300"
              >
                {c}
              </span>
            ))}
          </div>
        )}
        <div className="flex items-end justify-between mt-auto pt-2">
          <div>
            <span className="text-lg font-bold">{formatPKR(product.price)}</span>
            {product.compare_price && product.compare_price > product.price && (
              <span className="ml-2 text-xs text-slate-500 line-through">
                {formatPKR(product.compare_price)}
              </span>
            )}
          </div>
          <button
            onClick={handleAdd}
            disabled={outOfStock}
            className="w-10 h-10 rounded-full bg-gradient-to-br from-accent-cyan to-accent-purple text-ink-950 grid place-items-center disabled:opacity-40 hover:scale-110 transition-transform"
            aria-label="Add to cart"
          >
            <ShoppingCart className="w-4 h-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
