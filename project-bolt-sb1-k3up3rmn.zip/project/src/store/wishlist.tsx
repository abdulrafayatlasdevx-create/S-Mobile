import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './auth';

interface WishlistCtx {
  ids: string[];
  toggle: (productId: string) => void;
  has: (productId: string) => boolean;
  count: number;
}

const Ctx = createContext<WishlistCtx>(null!);
const LOCAL_KEY = 'smobile-wishlist';

export function WishlistProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [ids, setIds] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(LOCAL_KEY) || '[]');
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(LOCAL_KEY, JSON.stringify(ids));
  }, [ids]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase
        .from('wishlists')
        .select('product_id')
        .eq('user_id', user.id);
      if (data && data.length > 0) {
        setIds(data.map((r) => r.product_id as string));
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const toggle = useCallback(
    (productId: string) => {
      setIds((prev) => {
        const exists = prev.includes(productId);
        const next = exists
          ? prev.filter((id) => id !== productId)
          : [...prev, productId];
        if (user) {
          if (exists) {
            supabase
              .from('wishlists')
              .delete()
              .eq('user_id', user.id)
              .eq('product_id', productId);
          } else {
            supabase
              .from('wishlists')
              .insert({ user_id: user.id, product_id: productId });
          }
        }
        return next;
      });
    },
    [user]
  );

  const has = useCallback((id: string) => ids.includes(id), [ids]);

  return (
    <Ctx.Provider value={{ ids, toggle, has, count: ids.length }}>
      {children}
    </Ctx.Provider>
  );
}

export function useWishlist() {
  return useContext(Ctx);
}
