import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { supabase } from '../lib/supabase';
import type { CartItem } from '../lib/types';
import { useAuth } from './auth';

interface CartCtx {
  items: CartItem[];
  add: (item: CartItem) => void;
  remove: (productId: string) => void;
  setQty: (productId: string, qty: number) => void;
  clear: () => void;
  total: number;
  count: number;
  open: boolean;
  setOpen: (v: boolean) => void;
}

const Ctx = createContext<CartCtx>(null!);

const LOCAL_KEY = 'smobile-cart';

export function CartProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(LOCAL_KEY) || '[]');
    } catch {
      return [];
    }
  });
  const [open, setOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem(LOCAL_KEY, JSON.stringify(items));
  }, [items]);

  // Sync to server when signed in
  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase
        .from('carts')
        .select('id,items')
        .eq('user_id', user.id)
        .maybeSingle();
      if (data) {
        const serverItems = (data.items as CartItem[]) || [];
        if (serverItems.length === 0 && items.length > 0) {
          await supabase.from('carts').update({ items }).eq('id', data.id);
        } else if (serverItems.length > 0) {
          setItems(serverItems);
        }
      } else if (items.length > 0) {
        await supabase.from('carts').insert({ user_id: user.id, items });
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const persist = useCallback(
    async (next: CartItem[]) => {
      setItems(next);
      if (user) {
        const { data } = await supabase
          .from('carts')
          .select('id')
          .eq('user_id', user.id)
          .maybeSingle();
        if (data) {
          await supabase.from('carts').update({ items: next }).eq('id', data.id);
        } else {
          await supabase.from('carts').insert({ user_id: user.id, items: next });
        }
      }
    },
    [user]
  );

  const add = useCallback(
    (item: CartItem) => {
      setItems((prev) => {
        const idx = prev.findIndex(
          (i) =>
            i.product_id === item.product_id &&
            JSON.stringify(i.variant) === JSON.stringify(item.variant)
        );
        let next: CartItem[];
        if (idx >= 0) {
          next = prev.map((i, k) =>
            k === idx ? { ...i, quantity: i.quantity + item.quantity } : i
          );
        } else {
          next = [...prev, item];
        }
        persist(next);
        return next;
      });
    },
    [persist]
  );

  const remove = useCallback(
    (productId: string) => {
      setItems((prev) => {
        const next = prev.filter((i) => i.product_id !== productId);
        persist(next);
        return next;
      });
    },
    [persist]
  );

  const setQty = useCallback(
    (productId: string, qty: number) => {
      setItems((prev) => {
        const next = prev.map((i) =>
          i.product_id === productId
            ? { ...i, quantity: Math.max(1, qty) }
            : i
        );
        persist(next);
        return next;
      });
    },
    [persist]
  );

  const clear = useCallback(() => {
    setItems([]);
    if (user) {
      supabase
        .from('carts')
        .delete()
        .eq('user_id', user.id);
    }
  }, [user]);

  const total = useMemo(
    () => items.reduce((s, i) => s + i.price * i.quantity, 0),
    [items]
  );
  const count = useMemo(
    () => items.reduce((s, i) => s + i.quantity, 0),
    [items]
  );

  return (
    <Ctx.Provider
      value={{ items, add, remove, setQty, clear, total, count, open, setOpen }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useCart() {
  return useContext(Ctx);
}
