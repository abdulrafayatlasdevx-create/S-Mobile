import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { SlidersHorizontal, X } from 'lucide-react';
import ProductCard from '../../components/product/ProductCard';
import { useBrands, useCategories, useProducts } from '../../lib/hooks';
import { classNames } from '../../lib/utils';

export default function Products() {
  const [params, setParams] = useSearchParams();
  const search = params.get('search') || '';
  const category = params.get('category') || '';
  const brand = params.get('brand') || '';

  const { products, loading } = useProducts({
    category: category || undefined,
    brand: brand || undefined,
    search: search || undefined,
  });
  const brands = useBrands();
  const categories = useCategories();

  const [filtersOpen, setFiltersOpen] = useState(false);
  const [maxPrice, setMaxPrice] = useState(500000);
  const [inStock, setInStock] = useState(false);
  const [only5G, setOnly5G] = useState(false);

  const filtered = useMemo(() => {
    return products.filter((p) => {
      if (p.price > maxPrice) return false;
      if (inStock && p.stock <= 0) return false;
      if (only5G && !p.tags.includes('5G')) return false;
      return true;
    });
  }, [products, maxPrice, inStock, only5G]);

  const updateParam = (key: string, value: string) => {
    const next = new URLSearchParams(params);
    if (value) next.set(key, value);
    else next.delete(key);
    setParams(next);
  };

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, []);

  return (
    <div className="pt-24 pb-24 px-6 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <header className="mb-10">
          <h1 className="font-display font-bold text-4xl sm:text-5xl">
            {search ? `Results for "${search}"` : 'All Products'}
          </h1>
          <p className="mt-2 text-slate-400">
            {filtered.length} item{filtered.length !== 1 ? 's' : ''} found
          </p>
        </header>

        <div className="flex gap-8">
          {/* Sidebar */}
          <aside
            className={classNames(
              'hidden lg:block w-64 shrink-0 glass rounded-2xl p-6 h-fit sticky top-24',
              filtersOpen ? 'block' : 'hidden'
            )}
          >
            <Filters
              categories={categories}
              brands={brands}
              category={category}
              brand={brand}
              updateParam={updateParam}
              maxPrice={maxPrice}
              setMaxPrice={setMaxPrice}
              inStock={inStock}
              setInStock={setInStock}
              only5G={only5G}
              setOnly5G={setOnly5G}
            />
          </aside>

          <div className="flex-1">
            <button
              onClick={() => setFiltersOpen((v) => !v)}
              className="lg:hidden mb-4 inline-flex items-center gap-2 glass rounded-full px-4 py-2 text-sm"
            >
              <SlidersHorizontal className="w-4 h-4" /> Filters
            </button>
            {filtersOpen && (
              <div className="lg:hidden mb-4 glass rounded-2xl p-6">
                <Filters
                  categories={categories}
                  brands={brands}
                  category={category}
                  brand={brand}
                  updateParam={updateParam}
                  maxPrice={maxPrice}
                  setMaxPrice={setMaxPrice}
                  inStock={inStock}
                  setInStock={setInStock}
                  only5G={only5G}
                  setOnly5G={setOnly5G}
                />
              </div>
            )}

            {loading ? (
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-5">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="skeleton rounded-2xl aspect-[4/5]" />
                ))}
              </div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-20 text-slate-400">
                <p>No products match your filters.</p>
              </div>
            ) : (
              <motion.div
                layout
                className="grid grid-cols-2 lg:grid-cols-3 gap-5"
              >
                {filtered.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Filters({
  categories,
  brands,
  category,
  brand,
  updateParam,
  maxPrice,
  setMaxPrice,
  inStock,
  setInStock,
  only5G,
  setOnly5G,
}: any) {
  return (
    <div className="space-y-7">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Filters</h3>
      </div>
      <div>
        <p className="text-xs uppercase tracking-widest text-accent-cyan mb-3">
          Category
        </p>
        <div className="flex flex-col gap-1.5">
          <button
            onClick={() => updateParam('category', '')}
            className={classNames(
              'text-sm text-left px-3 py-1.5 rounded-lg transition-colors',
              !category ? 'bg-white/10 text-accent-cyan' : 'text-slate-300 hover:bg-white/5'
            )}
          >
            All
          </button>
          {categories.map((c: any) => (
            <button
              key={c.id}
              onClick={() => updateParam('category', c.slug)}
              className={classNames(
                'text-sm text-left px-3 py-1.5 rounded-lg transition-colors',
                category === c.slug
                  ? 'bg-white/10 text-accent-cyan'
                  : 'text-slate-300 hover:bg-white/5'
              )}
            >
              {c.name}
            </button>
          ))}
        </div>
      </div>
      <div>
        <p className="text-xs uppercase tracking-widest text-accent-cyan mb-3">
          Brand
        </p>
        <div className="flex flex-col gap-1.5">
          <button
            onClick={() => updateParam('brand', '')}
            className={classNames(
              'text-sm text-left px-3 py-1.5 rounded-lg transition-colors',
              !brand ? 'bg-white/10 text-accent-cyan' : 'text-slate-300 hover:bg-white/5'
            )}
          >
            All
          </button>
          {brands.map((b: any) => (
            <button
              key={b.id}
              onClick={() => updateParam('brand', b.slug)}
              className={classNames(
                'text-sm text-left px-3 py-1.5 rounded-lg transition-colors',
                brand === b.slug
                  ? 'bg-white/10 text-accent-cyan'
                  : 'text-slate-300 hover:bg-white/5'
              )}
            >
              {b.name}
            </button>
          ))}
        </div>
      </div>
      <div>
        <p className="text-xs uppercase tracking-widest text-accent-cyan mb-3">
          Max Price
        </p>
        <input
          type="range"
          min={5000}
          max={500000}
          step={5000}
          value={maxPrice}
          onChange={(e) => setMaxPrice(Number(e.target.value))}
          className="w-full accent-accent-cyan"
        />
        <p className="text-sm mt-1">Rs. {maxPrice.toLocaleString()}</p>
      </div>
      <div className="space-y-2">
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={inStock}
            onChange={(e) => setInStock(e.target.checked)}
            className="accent-accent-cyan"
          />
          In stock only
        </label>
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={only5G}
            onChange={(e) => setOnly5G(e.target.checked)}
            className="accent-accent-cyan"
          />
          5G only
        </label>
      </div>
    </div>
  );
}
