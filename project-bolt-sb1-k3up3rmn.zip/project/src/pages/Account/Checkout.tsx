import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle2, CreditCard, Truck } from 'lucide-react';
import { useCart } from '../../store/cart';
import { useAuth } from '../../store/auth';
import { useToast } from '../../store/toast';
import { supabase } from '../../lib/supabase';
import { formatPKR } from '../../lib/utils';
import MagneticButton from '../../components/common/MagneticButton';

export default function Checkout() {
  const { items, total, clear } = useCart();
  const { user } = useAuth();
  const { push } = useToast();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [method, setMethod] = useState<'COD' | 'Card'>('COD');
  const [placed, setPlaced] = useState(false);

  if (!user) return <Navigate to="/login" replace />;
  if (items.length === 0 && !placed)
    return (
      <div className="pt-32 text-center min-h-screen px-6">
        <h1 className="text-2xl font-bold">Your cart is empty</h1>
        <Link to="/products" className="text-accent-cyan mt-4 inline-block">
          Browse products
        </Link>
      </div>
    );

  const placeOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    const { data: order } = await supabase
      .from('orders')
      .insert({
        user_id: user!.id,
        total,
        status: 'Pending',
        payment_method: method,
        shipping_address: { name, phone, address, city },
      })
      .select()
      .single();
    if (order) {
      await supabase.from('order_items').insert(
        items.map((i) => ({
          order_id: order.id,
          product_id: i.product_id,
          name: i.name,
          image_url: i.image,
          variant: i.variant || {},
          price: i.price,
          quantity: i.quantity,
        }))
      );
      clear();
      setPlaced(true);
      push('Order placed successfully!');
    }
  };

  if (placed) {
    return (
      <div className="pt-32 pb-24 px-6 min-h-screen flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-strong rounded-3xl p-10 text-center max-w-md"
        >
          <CheckCircle2 className="w-16 h-16 text-emerald-400 mx-auto mb-4" />
          <h1 className="font-display font-bold text-3xl">Order Placed!</h1>
          <p className="mt-3 text-slate-400">
            Thank you for your purchase. We'll contact you shortly to confirm.
          </p>
          <div className="mt-6 flex gap-3 justify-center">
            <Link to="/account?tab=orders">
              <MagneticButton>View Orders</MagneticButton>
            </Link>
            <Link to="/products">
              <MagneticButton variant="outline">Continue Shopping</MagneticButton>
            </Link>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-24 px-6 min-h-screen">
      <div className="max-w-5xl mx-auto">
        <h1 className="font-display font-bold text-3xl sm:text-4xl mb-8">Checkout</h1>
        <form onSubmit={placeOrder} className="grid lg:grid-cols-[1fr_360px] gap-6">
          <div className="space-y-6">
            <div className="glass rounded-2xl p-6">
              <h2 className="font-semibold mb-4">Delivery Information</h2>
              <div className="grid sm:grid-cols-2 gap-3">
                <Field label="Full name" value={name} onChange={setName} required />
                <Field label="Phone" value={phone} onChange={setPhone} required />
                <div className="sm:col-span-2">
                  <Field label="Address" value={address} onChange={setAddress} required />
                </div>
                <Field label="City" value={city} onChange={setCity} required />
              </div>
            </div>
            <div className="glass rounded-2xl p-6">
              <h2 className="font-semibold mb-4">Payment Method</h2>
              <div className="grid sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setMethod('COD')}
                  className={`glass rounded-xl p-4 text-left flex items-center gap-3 border-2 transition-colors ${
                    method === 'COD' ? 'border-accent-cyan' : 'border-transparent'
                  }`}
                >
                  <Truck className="w-5 h-5 text-accent-cyan" />
                  <div>
                    <p className="font-medium text-sm">Cash on Delivery</p>
                    <p className="text-xs text-slate-400">Pay when you receive</p>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => setMethod('Card')}
                  className={`glass rounded-xl p-4 text-left flex items-center gap-3 border-2 transition-colors ${
                    method === 'Card' ? 'border-accent-cyan' : 'border-transparent'
                  }`}
                >
                  <CreditCard className="w-5 h-5 text-accent-cyan" />
                  <div>
                    <p className="font-medium text-sm">Card (Future)</p>
                    <p className="text-xs text-slate-400">Coming soon</p>
                  </div>
                </button>
              </div>
            </div>
          </div>

          <aside className="glass rounded-2xl p-6 h-fit sticky top-24">
            <h2 className="font-semibold mb-4">Order Summary</h2>
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {items.map((i) => (
                <div key={i.product_id + JSON.stringify(i.variant)} className="flex gap-3 text-sm">
                  <img src={i.image} alt="" className="w-12 h-12 rounded-lg object-cover" />
                  <div className="flex-1">
                    <p className="line-clamp-1">{i.name}</p>
                    <p className="text-xs text-slate-400">x{i.quantity}</p>
                  </div>
                  <span>{formatPKR(i.price * i.quantity)}</span>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t border-white/10 flex justify-between">
              <span className="text-slate-400">Total</span>
              <span className="text-2xl font-bold font-display">{formatPKR(total)}</span>
            </div>
            <MagneticButton type="submit" className="w-full mt-5">
              Place Order
            </MagneticButton>
          </aside>
        </form>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, required }: any) {
  return (
    <div>
      <label className="text-xs text-slate-400 uppercase tracking-widest">{label}</label>
      <input
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full glass rounded-xl px-4 py-2.5 outline-none text-sm"
      />
    </div>
  );
}
