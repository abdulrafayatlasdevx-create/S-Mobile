import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, Lock, User as UserIcon, ArrowRight } from 'lucide-react';
import { useAuth } from '../../store/auth';
import { useToast } from '../../store/toast';
import MagneticButton from '../../components/common/MagneticButton';

export default function Login() {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const { signIn, signUp } = useAuth();
  const { push } = useToast();
  const navigate = useNavigate();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    if (mode === 'login') {
      const { error } = await signIn(email, password);
      if (error) push(error, 'error');
      else {
        push('Welcome back!');
        navigate('/account');
      }
    } else {
      const { error } = await signUp(email, password, name);
      if (error) push(error, 'error');
      else {
        push('Account created. Welcome!');
        navigate('/account');
      }
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen pt-24 pb-16 px-6 flex items-center justify-center">
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[500px] h-[500px] rounded-full bg-accent-purple/20 blur-[120px] pointer-events-none" />
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative glass-strong rounded-3xl p-8 sm:p-10 w-full max-w-md"
      >
        <Link to="/" className="flex items-center gap-2 mb-8">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent-cyan to-accent-purple grid place-items-center text-ink-950 font-bold">
            S
          </div>
          <span className="font-display font-bold text-xl">
            S <span className="text-gradient">Mobile</span>
          </span>
        </Link>

        <div className="flex gap-2 mb-6 glass rounded-full p-1">
          {(['login', 'signup'] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`flex-1 py-2 rounded-full text-sm font-medium capitalize transition-colors ${
                mode === m
                  ? 'bg-gradient-to-r from-accent-cyan to-accent-purple text-ink-950'
                  : 'text-slate-300'
              }`}
            >
              {m === 'login' ? 'Sign In' : 'Sign Up'}
            </button>
          ))}
        </div>

        <form onSubmit={submit} className="space-y-4">
          {mode === 'signup' && (
            <Field icon={UserIcon} placeholder="Full name" value={name} onChange={setName} />
          )}
          <Field icon={Mail} type="email" placeholder="Email" value={email} onChange={setEmail} />
          <Field icon={Lock} type="password" placeholder="Password" value={password} onChange={setPassword} />
          <MagneticButton type="submit" className="w-full" disabled={loading}>
            {loading ? 'Please wait...' : mode === 'login' ? 'Sign In' : 'Create Account'}
            <ArrowRight className="w-4 h-4" />
          </MagneticButton>
        </form>

        <p className="mt-6 text-xs text-slate-400 text-center">
          By continuing you agree to S Mobile's Terms & Privacy Policy.
        </p>
      </motion.div>
    </div>
  );
}

function Field({
  icon: Icon,
  type = 'text',
  placeholder,
  value,
  onChange,
}: any) {
  return (
    <div className="flex items-center gap-3 glass rounded-xl px-4 py-3">
      <Icon className="w-4 h-4 text-slate-400" />
      <input
        type={type}
        required
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="flex-1 bg-transparent outline-none text-sm"
      />
    </div>
  );
}
