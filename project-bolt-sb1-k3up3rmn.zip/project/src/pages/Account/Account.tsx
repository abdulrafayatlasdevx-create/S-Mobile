import { useEffect, useState } from 'react';
import { Link, Navigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  User as UserIcon,
  ShoppingBag,
  Heart,
  Bell,
  MapPin,
  LogOut,
  Package,
  Clock,
} from 'lucide-react';
import { useAuth } from '../../store/auth';
import { useToast } from '../../store/toast';
import { useWishlist } from '../../store/wishlist';
import { useProducts } from '../../lib/hooks';
import { supabase } from '../../lib/supabase';
import type { OrderRow, OrderItemRow } from '../../lib/types';
import { formatPKR } from '../../lib/utils';

const TABS = [
  { key: 'profile', label: 'Profile', icon: UserIcon },
  { key: 'orders', label: 'Orders', icon: Package },
  { key: 'wishlist', label: 'Wishlist', icon: Heart },
  { key: 'addresses', label: 'Addresses', icon: MapPin },
  { key: 'notifications', label: 'Notifications', icon: Bell },
];

export default function Account() {
  const { user, profile, signOut, loading } = useAuth();
  const [params, setParams] = useSearchParams();
  const tab = params.get('tab') || 'profile';

  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;

  return (
    <div className="pt-24 pb-24 px-6 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-10">
          <div>
            <h1 className="font-display font-bold text-3xl sm:text-4xl">
              Hi, {profile?.full_name || user.email}
            </h1>
            <p className="text-slate-400 mt-1">
              {profile?.role === 'admin' || profile?.role === 'super_admin'
                ? 'Administrator account'
                : 'Customer account'}
            </p>
          </div>
          <button
            onClick={signOut}
            className="inline-flex items-center gap-2 glass rounded-full px-4 py-2 text-sm hover:bg-white/10"
          >
            <LogOut className="w-4 h-4" /> Sign out
          </button>
        </div>

        <div className="grid lg:grid-cols-[260px_1fr] gap-6">
          <aside className="glass rounded-2xl p-3 h-fit">
            <nav className="flex lg:flex-col gap-1 overflow-x-auto">
              {TABS.map((t) => (
                <button
                  key={t.key}
                  onClick={() => setParams({ tab: t.key })}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm whitespace-nowrap transition-colors ${
                    tab === t.key
                      ? 'bg-white/10 text-accent-cyan'
                      : 'text-slate-300 hover:bg-white/5'
                  }`}
                >
                  <t.icon className="w-4 h-4" /> {t.label}
                </button>
              ))}
              {(profile?.role === 'admin' || profile?.role === 'super_admin') && (
                <Link
                  to="/admin"
                  className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-accent-purple hover:bg-white/5"
                >
                  <ShoppingBag className="w-4 h-4" /> Admin Dashboard
                </Link>
              )}
            </nav>
          </aside>

          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass rounded-2xl p-6"
          >
            {tab === 'profile' && <Profile />}
            {tab === 'orders' && <Orders />}
            {tab === 'wishlist' && <Wishlist />}
            {tab === 'addresses' && <Addresses />}
            {tab === 'notifications' && <Notifications />}
          </motion.div>
        </div>
      </div>
    </div>
  );
}

function Profile() {
  const { user, profile, refreshProfile } = useAuth();
  const { push } = useToast();
  const [name, setName] = useState(profile?.full_name || '');
  const [phone, setPhone] = useState(profile?.phone || '');

  const save = async () => {
    await supabase.from('profiles').upsert({
      id: user!.id,
      full_name: name,
      phone,
      role: profile?.role || 'customer',
    });
    await refreshProfile();
    push('Profile updated');
  };

  return (
    <div>
      <h2 className="font-display font-bold text-2xl mb-6">Profile</h2>
      <div className="space-y-4 max-w-md">
        <Field label="Full name" value={name} onChange={setName} />
        <Field label="Email" value={user?.email || ''} disabled />
        <Field label="Phone" value={phone} onChange={setPhone} />
        <button
          onClick={save}
          className="px-6 py-2.5 rounded-full bg-gradient-to-r from-accent-cyan to-accent-purple text-ink-950 font-semibold text-sm"
        >
          Save Changes
        </button>
      </div>
    </div>
  );
}

function Orders() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [items, setItems] = useState<Record<string, OrderItemRow[]>>({});

  useEffect(() => {
    if (!user) return;
    supabase
      .from('orders')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .then(async ({ data }) => {
        if (data) {
          setOrders(data as OrderRow[]);
          const all: Record<string, OrderItemRow[]> = {};
          for (const o of data as OrderRow[]) {
            const r = await supabase
              .from('order_items')
              .select('*')
              .eq('order_id', o.id);
            all[o.id] = (r.data || []) as OrderItemRow[];
          }
          setItems(all);
        }
      });
  }, [user]);

  if (orders.length === 0)
    return <p className="text-slate-400">No orders yet.</p>;

  return (
    <div>
      <h2 className="font-display font-bold text-2xl mb-6">Order History</h2>
      <div className="space-y-4">
        {orders.map((o) => (
          <div key={o.id} className="glass rounded-2xl p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="font-medium">Order #{o.id.slice(0, 8)}</p>
                <p className="text-xs text-slate-400">
                  {new Date(o.created_at).toLocaleString()}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs px-3 py-1 rounded-full bg-accent-cyan/15 text-accent-cyan">
                  {o.status}
                </span>
                <span className="font-bold">{formatPKR(o.total)}</span>
              </div>
            </div>
            <div className="mt-4 space-y-2">
              {(items[o.id] || []).map((it) => (
                <div key={it.id} className="flex items-center gap-3 text-sm">
                  {it.image_url && (
                    <img src={it.image_url} alt="" className="w-10 h-10 rounded-lg object-cover" />
                  )}
                  <span className="flex-1">{it.name}</span>
                  <span className="text-slate-400">x{it.quantity}</span>
                  <span>{formatPKR(it.price * it.quantity)}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Wishlist() {
  const { ids } = useWishlist();
  const { products } = useProducts();
  const wish = products.filter((p) => ids.includes(p.id));
  if (wish.length === 0)
    return <p className="text-slate-400">Your wishlist is empty.</p>;
  return (
    <div>
      <h2 className="font-display font-bold text-2xl mb-6">Wishlist</h2>
      <div className="grid sm:grid-cols-2 gap-4">
        {wish.map((p) => (
          <Link
            key={p.id}
            to={`/products/${p.slug}`}
            className="glass rounded-2xl p-4 flex gap-3 hover:bg-white/5"
          >
            <img src={p.images[0]} alt="" className="w-20 h-20 rounded-lg object-cover" />
            <div>
              <p className="font-medium">{p.name}</p>
              <p className="text-sm text-accent-cyan">{formatPKR(p.price)}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

function Addresses() {
  return (
    <div>
      <h2 className="font-display font-bold text-2xl mb-6">Saved Addresses</h2>
      <p className="text-slate-400">
        Address management coming soon. Checkout supports one-time addresses.
      </p>
    </div>
  );
}

function Notifications() {
  const { user } = useAuth();
  const [list, setList] = useState<any[]>([]);
  useEffect(() => {
    if (!user) return;
    supabase
      .from('notifications')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .then(({ data }) => data && setList(data));
  }, [user]);
  if (list.length === 0)
    return (
      <div>
        <h2 className="font-display font-bold text-2xl mb-6">Notifications</h2>
        <p className="text-slate-400">No notifications.</p>
      </div>
    );
  return (
    <div>
      <h2 className="font-display font-bold text-2xl mb-6">Notifications</h2>
      <div className="space-y-3">
        {list.map((n) => (
          <div key={n.id} className="glass rounded-xl p-4 flex gap-3">
            <Bell className="w-4 h-4 text-accent-cyan mt-0.5" />
            <div>
              <p className="font-medium text-sm">{n.title}</p>
              {n.body && <p className="text-xs text-slate-400 mt-1">{n.body}</p>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Field({ label, value, onChange, disabled }: any) {
  return (
    <div>
      <label className="text-xs text-slate-400 uppercase tracking-widest">
        {label}
      </label>
      <input
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        disabled={disabled}
        className="mt-1 w-full glass rounded-xl px-4 py-3 outline-none disabled:opacity-60"
      />
    </div>
  );
}
