import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Heart,
  Share2,
  ShoppingCart,
  Check,
  Truck,
  ShieldCheck,
  ChevronRight,
  Star,
} from 'lucide-react';
import { useProduct, useReviews } from '../../lib/hooks';
import { useCart } from '../../store/cart';
import { useWishlist } from '../../store/wishlist';
import { useToast } from '../../store/toast';
import { classNames, formatPKR, discountPercent, share } from '../../lib/utils';
import MagneticButton from '../../components/common/MagneticButton';
import ProductCard from '../../components/product/ProductCard';
import { useProducts } from '../../lib/hooks';

export default function ProductDetails() {
  const { slug } = useParams();
  const { product, loading } = useProduct(slug || '');
  const { reviews } = useReviews(product?.id);
  const { add, setOpen } = useCart();
  const { has, toggle } = useWishlist();
  const { push } = useToast();
  const { products: related } = useProducts();
  const [activeImg, setActiveImg] = useState(0);
  const [color, setColor] = useState<string>('');
  const [storage, setStorage] = useState<string>('');
  const [qty, setQty] = useState(1);

  if (loading) {
    return (
      <div className="pt-32 px-6 max-w-7xl mx-auto">
        <div className="skeleton rounded-3xl h-[500px]" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="pt-40 text-center min-h-screen">
        <h1 className="text-3xl font-bold">Product not found</h1>
        <Link to="/products" className="text-accent-cyan mt-4 inline-block">
          Back to products
        </Link>
      </div>
    );
  }

  const inWishlist = has(product.id);
  const discount = discountPercent(product.price, product.compare_price);
  const brandName = (product as unknown as { brands?: { name: string } }).brands?.name;
  const relatedProducts = related
    .filter((p) => p.id !== product.id && p.category_id === product.category_id)
    .slice(0, 4);

  const handleAdd = () => {
    add({
      product_id: product.id,
      name: product.name,
      slug: product.slug,
      image: product.images[0] || '',
      price: product.price,
      quantity: qty,
      variant: {
        color: color || product.variants.colors?.[0],
        storage: storage || product.variants.storage?.[0],
      },
    });
    push(`${product.name} added to cart`);
    setOpen(true);
  };

  return (
    <div className="pt-24 pb-24 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-1.5 text-sm text-slate-400 mb-6">
          <Link to="/" className="hover:text-accent-cyan">Home</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <Link to="/products" className="hover:text-accent-cyan">Products</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-slate-200">{product.name}</span>
        </nav>

        <div className="grid lg:grid-cols-2 gap-10">
          {/* Gallery */}
          <div>
            <motion.div
              key={activeImg}
              initial={{ opacity: 0.4, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative aspect-square rounded-3xl overflow-hidden glass"
            >
              <img
                src={product.images[activeImg]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              {discount && (
                <span className="absolute top-4 left-4 px-3 py-1.5 rounded-full bg-gradient-to-r from-accent-cyan to-accent-purple text-ink-950 text-sm font-bold">
                  -{discount}%
                </span>
              )}
            </motion.div>
            {product.images.length > 1 && (
              <div className="mt-4 grid grid-cols-4 gap-3">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImg(i)}
                    className={classNames(
                      'aspect-square rounded-xl overflow-hidden border-2 transition-colors',
                      activeImg === i ? 'border-accent-cyan' : 'border-transparent opacity-70'
                    )}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div>
            {brandName && (
              <span className="text-xs uppercase tracking-widest text-accent-cyan">
                {brandName}
              </span>
            )}
            <h1 className="mt-2 font-display font-bold text-3xl sm:text-4xl">
              {product.name}
            </h1>
            <div className="mt-3 flex items-center gap-3">
              <div className="flex text-amber-400">
                {'★'.repeat(Math.round(product.rating))}
              </div>
              <span className="text-sm text-slate-400">
                {product.rating} ({product.reviews_count} reviews)
              </span>
            </div>

            <div className="mt-5 flex items-end gap-3">
              <span className="text-4xl font-bold font-display">
                {formatPKR(product.price)}
              </span>
              {product.compare_price && product.compare_price > product.price && (
                <span className="text-lg text-slate-500 line-through mb-1">
                  {formatPKR(product.compare_price)}
                </span>
              )}
            </div>

            <p className="mt-5 text-slate-300 leading-relaxed">
              {product.description || product.short_description}
            </p>

            {/* Variants */}
            {product.variants.colors && (
              <div className="mt-6">
                <p className="text-sm text-slate-400 mb-2">Color</p>
                <div className="flex flex-wrap gap-2">
                  {product.variants.colors.map((c) => (
                    <button
                      key={c}
                      onClick={() => setColor(c)}
                      className={classNames(
                        'px-4 py-2 rounded-full text-sm border transition-colors',
                        (color || product.variants.colors[0]) === c
                          ? 'border-accent-cyan text-accent-cyan'
                          : 'border-white/15 text-slate-300'
                      )}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {product.variants.storage && (
              <div className="mt-4">
                <p className="text-sm text-slate-400 mb-2">Storage</p>
                <div className="flex flex-wrap gap-2">
                  {product.variants.storage.map((s) => (
                    <button
                      key={s}
                      onClick={() => setStorage(s)}
                      className={classNames(
                        'px-4 py-2 rounded-full text-sm border transition-colors',
                        (storage || product.variants.storage[0]) === s
                          ? 'border-accent-cyan text-accent-cyan'
                          : 'border-white/15 text-slate-300'
                      )}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity + actions */}
            <div className="mt-6 flex items-center gap-3">
              <div className="glass rounded-full flex items-center">
                <button
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  className="w-10 h-10 grid place-items-center"
                >
                  −
                </button>
                <span className="w-10 text-center">{qty}</span>
                <button
                  onClick={() => setQty((q) => q + 1)}
                  className="w-10 h-10 grid place-items-center"
                >
                  +
                </button>
              </div>
              <MagneticButton onClick={handleAdd} className="flex-1">
                <ShoppingCart className="w-4 h-4" /> Add to Cart
              </MagneticButton>
              <button
                onClick={() => {
                  toggle(product.id);
                  push(inWishlist ? 'Removed from wishlist' : 'Added to wishlist');
                }}
                className={classNames(
                  'w-12 h-12 rounded-full glass grid place-items-center',
                  inWishlist ? 'text-rose-400' : ''
                )}
              >
                {inWishlist ? <Check className="w-5 h-5" /> : <Heart className="w-5 h-5" />}
              </button>
              <button
                onClick={() => {
                  share(product.name, window.location.href);
                  push('Link copied');
                }}
                className="w-12 h-12 rounded-full glass grid place-items-center"
              >
                <Share2 className="w-5 h-5" />
              </button>
            </div>

            {/* Trust badges */}
            <div className="mt-8 grid grid-cols-2 gap-3">
              <div className="glass rounded-xl p-3 flex items-center gap-2 text-sm">
                <Truck className="w-4 h-4 text-accent-cyan" /> Fast nationwide delivery
              </div>
              <div className="glass rounded-xl p-3 flex items-center gap-2 text-sm">
                <ShieldCheck className="w-4 h-4 text-accent-cyan" /> Official warranty
              </div>
            </div>

            {/* Specs */}
            {Object.keys(product.specs).length > 0 && (
              <div className="mt-8">
                <h3 className="font-semibold mb-3">Specifications</h3>
                <div className="glass rounded-2xl divide-y divide-white/5">
                  {Object.entries(product.specs).map(([k, v]) => (
                    <div key={k} className="flex justify-between px-4 py-2.5 text-sm">
                      <span className="text-slate-400 capitalize">{k}</span>
                      <span className="text-slate-200">{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Reviews */}
        <section className="mt-16">
          <h2 className="font-display font-bold text-2xl mb-6">Customer Reviews</h2>
          {reviews.length === 0 ? (
            <p className="text-slate-400">No reviews yet. Be the first!</p>
          ) : (
            <div className="grid md:grid-cols-2 gap-4">
              {reviews.map((r) => (
                <div key={r.id} className="glass rounded-2xl p-5">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{r.author_name || 'Anonymous'}</span>
                    <div className="flex text-amber-400 text-xs">
                      {'★'.repeat(r.rating)}
                    </div>
                  </div>
                  {r.title && <p className="mt-2 font-medium">{r.title}</p>}
                  <p className="mt-1 text-sm text-slate-300">{r.body}</p>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Related */}
        {relatedProducts.length > 0 && (
          <section className="mt-16">
            <h2 className="font-display font-bold text-2xl mb-6">You May Also Like</h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
              {relatedProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
