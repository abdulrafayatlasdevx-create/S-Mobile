import { motion } from 'framer-motion';
import { Mail, MapPin, Phone, MessageCircle } from 'lucide-react';
import { useSettings } from '../../lib/hooks';
import MagneticButton from '../../components/common/MagneticButton';

export default function Contact() {
  const settings = useSettings();
  return (
    <div className="pt-24 pb-24 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <span className="text-xs uppercase tracking-widest text-accent-cyan">
            Get in touch
          </span>
          <h1 className="mt-3 font-display font-bold text-5xl sm:text-6xl">
            Contact <span className="text-gradient">Us</span>
          </h1>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          <div className="glass rounded-3xl p-8 space-y-6">
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-accent-cyan mt-1" />
              <div>
                <p className="font-semibold">Address</p>
                <p className="text-slate-400 text-sm mt-1">{settings?.address}</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Phone className="w-5 h-5 text-accent-cyan mt-1" />
              <div>
                <p className="font-semibold">Phones</p>
                <p className="text-slate-400 text-sm mt-1">
                  Sajid Qureshi: {settings?.contact_phone1} / {settings?.contact_phone2}
                  <br />
                  Shakeel Qureshi: {settings?.contact_phone3}
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Mail className="w-5 h-5 text-accent-cyan mt-1" />
              <div>
                <p className="font-semibold">Email</p>
                <p className="text-slate-400 text-sm mt-1">info@smobile.pk</p>
              </div>
            </div>
            <a
              href={`https://wa.me/${settings?.whatsapp || '923017504004'}`}
              target="_blank"
              rel="noreferrer"
            >
              <MagneticButton>
                <MessageCircle className="w-4 h-4" /> Chat on WhatsApp
              </MagneticButton>
            </a>
          </div>
          <div className="rounded-3xl overflow-hidden min-h-[420px] glass">
            <iframe
              title="S Mobile Location"
              src="https://www.google.com/maps?q=Shujaabad,Pakistan&output=embed"
              className="w-full h-full min-h-[420px]"
              loading="lazy"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
