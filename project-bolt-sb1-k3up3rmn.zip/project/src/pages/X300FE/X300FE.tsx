import { lazy, Suspense, useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import {
  ArrowRight,
  Cpu,
  Battery as BatteryIcon,
  Camera as CameraIcon,
  Smartphone,
  Wifi,
  Shield,
  Zap,
  Check,
  MessageCircle,
  ShoppingBag,
} from 'lucide-react';
import { useX300Specs, useReviews } from '../../lib/hooks';
import { formatPKR } from '../../lib/utils';
import MagneticButton from '../../components/common/MagneticButton';

const Hero3D = lazy(() => import('../../components/animations/Hero3D'));

const NAV = [
  'design', 'colors', 'display', 'camera', 'ai', 'processor',
  'battery', 'software', 'connectivity', 'security', 'specs', 'gallery',
  'compare', 'reviews', 'faq',
];

export default function X300FE() {
  const specs = useX300Specs();
  const { reviews } = useReviews(undefined);
  const [active, setActive] = useState('design');

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, []);

  useEffect(() => {
    const onScroll = () => {
      for (const id of NAV) {
        const el = document.getElementById(id);
        if (el) {
          const r = el.getBoundingClientRect();
          if (r.top <= 200 && r.bottom >= 200) {
            setActive(id);
            return;
          }
        }
      }
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div className="pt-16">
      {/* Sticky section nav */}
      <div className="sticky top-16 z-40 glass-strong border-y border-white/10">
        <div className="max-w-7xl mx-auto px-4 overflow-x-auto no-scrollbar">
          <div className="flex gap-1 py-2">
            {NAV.map((n) => (
              <a
                key={n}
                href={`#${n}`}
                className={`px-3 py-1.5 rounded-full text-xs capitalize whitespace-nowrap transition-colors ${
                  active === n
                    ? 'bg-gradient-to-r from-accent-cyan to-accent-purple text-ink-950 font-semibold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {n}
              </a>
            ))}
          </div>
        </div>
      </div>

      <Hero specs={specs} />
      <Design specs={specs} />
      <Colors specs={specs} />
      <Display specs={specs} />
      <Camera specs={specs} />
      <AI />
      <Processor specs={specs} />
      <Battery specs={specs} />
      <Software specs={specs} />
      <Connectivity specs={specs} />
      <Security specs={specs} />
      <Specs specs={specs} />
      <Gallery />
      <Compare specs={specs} />
      <Reviews reviews={reviews} />
      <FAQ specs={specs} />

      {/* Sticky CTA */}
      <div className="fixed bottom-5 inset-x-4 z-50 flex justify-center">
        <div className="glass-strong rounded-full px-3 py-2 flex items-center gap-2 shadow-card max-w-md w-full">
          <div className="flex-1 pl-3">
            <p className="text-xs text-slate-400">vivo X300 FE</p>
            <p className="text-sm font-bold">{specs ? formatPKR(specs.price) : ''}</p>
          </div>
          <a
            href="https://wa.me/923017504004"
            target="_blank"
            rel="noreferrer"
            className="w-11 h-11 rounded-full bg-emerald-500/20 text-emerald-300 grid place-items-center"
            aria-label="WhatsApp"
          >
            <MessageCircle className="w-5 h-5" />
          </a>
          <Link
            to="/checkout"
            className="px-5 py-3 rounded-full bg-gradient-to-r from-accent-cyan to-accent-purple text-ink-950 font-semibold text-sm flex items-center gap-2"
          >
            <ShoppingBag className="w-4 h-4" /> Buy Now
          </Link>
        </div>
      </div>
    </div>
  );
}

function Hero({ specs }: any) {
  const { scrollY } = useScroll();
  const opacity = useTransform(scrollY, [0, 500], [1, 0]);
  const scale = useTransform(scrollY, [0, 500], [1, 1.1]);

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-grid-faint bg-grid opacity-20" />
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[700px] h-[700px] rounded-full bg-accent-purple/20 blur-[140px]" />
      <motion.div style={{ opacity, scale }} className="relative z-10 text-center px-6 max-w-4xl">
        <motion.span
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold uppercase tracking-wider mb-6"
        >
          New Arrival · Available Now
        </motion.span>
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="font-display font-bold text-6xl sm:text-8xl leading-[1.02]"
        >
          vivo <span className="text-gradient">X300 FE</span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-5 text-xl text-slate-300"
        >
          The cinematic flagship. Snapdragon 8 Gen 5 · 6500mAh · 5000 nits.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-8 flex flex-wrap items-center justify-center gap-4"
        >
          <Link to="/checkout">
            <MagneticButton size="lg">
              Buy Now <ArrowRight className="w-4 h-4" />
            </MagneticButton>
          </Link>
          <a href="#specs">
            <MagneticButton size="lg" variant="outline">
              View Specifications
            </MagneticButton>
          </a>
        </motion.div>
        <p className="mt-6 text-2xl font-bold font-display">
          {specs ? formatPKR(specs.price) : ''}
        </p>
      </motion.div>
      <div className="absolute inset-0 z-0 pointer-events-none opacity-80">
        <Suspense fallback={null}>
          <Hero3D />
        </Suspense>
      </div>
    </section>
  );
}

function Reveal({ id, children, className = '' }: { id: string; children: React.ReactNode; className?: string }) {
  return (
    <section
      id={id}
      className={`relative py-28 px-6 scroll-mt-32 ${className}`}
    >
      <div className="max-w-7xl mx-auto">{children}</div>
    </section>
  );
}

function Eyebrow({ children }: { children: React.ReactNode }) {
  return (
    <motion.span
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="text-xs uppercase tracking-widest text-accent-cyan"
    >
      {children}
    </motion.span>
  );
}

function Design({ specs }: any) {
  return (
    <Reveal id="design">
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div>
          <Eyebrow>01 · Design</Eyebrow>
          <h2 className="mt-3 font-display font-bold text-4xl sm:text-5xl">
            Glass. Titanium. <span className="text-gradient">Iconic.</span>
          </h2>
          <p className="mt-5 text-slate-300 leading-relaxed">
            A glass back meets an aerospace-grade frame. IP68 & IP69 rated for
            total peace of mind. The 3D ultrasonic fingerprint unlocks in a blink.
          </p>
          <div className="mt-6 grid grid-cols-2 gap-3">
            <Stat label="Weight" value={specs?.design?.weight?.split(',')[0] || '191g'} />
            <Stat label="Build" value="Glass back" />
            <Stat label="IP Rating" value="IP68 & IP69" />
            <Stat label="Fingerprint" value="3D Ultrasonic" />
          </div>
        </div>
        <motion.div
          initial={{ opacity: 0, x: 40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="relative aspect-square rounded-3xl overflow-hidden glass"
        >
          <img
            src="https://images.pexels.com/photos/3568520/pexels-photo-3568520.jpeg"
            alt="Design"
            className="w-full h-full object-cover"
          />
        </motion.div>
      </div>
    </Reveal>
  );
}

function Colors({ specs }: any) {
  const colors = (specs?.colors as string[]) || ['Green', 'White', 'Black'];
  const swatches: Record<string, string> = {
    Green: 'linear-gradient(135deg,#0f3d2e,#1f8a5b)',
    White: 'linear-gradient(135deg,#f1f5f9,#cbd5e1)',
    Black: 'linear-gradient(135deg,#0b1120,#1e293b)',
  };
  return (
    <Reveal id="colors">
      <div className="text-center">
        <Eyebrow>02 · Colors</Eyebrow>
        <h2 className="mt-3 font-display font-bold text-4xl sm:text-5xl">
          Three Signature Shades
        </h2>
        <div className="mt-10 flex flex-wrap justify-center gap-6">
          {colors.map((c) => (
            <motion.div
              key={c}
              whileHover={{ y: -8 }}
              className="glass rounded-2xl p-6 w-44 text-center"
            >
              <div
                className="w-24 h-24 rounded-full mx-auto mb-3"
                style={{ background: swatches[c] || '#1e293b' }}
              />
              <p className="font-medium">{c}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </Reveal>
  );
}

function Display({ specs }: any) {
  return (
    <Reveal id="display">
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="relative aspect-square rounded-3xl overflow-hidden glass order-2 md:order-1"
        >
          <img
            src="https://images.pexels.com/photos/1841841/pexels-photo-1841841.jpeg"
            alt="Display"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-tr from-accent-cyan/30 to-transparent" />
        </motion.div>
        <div className="order-1 md:order-2">
          <Eyebrow>03 · Display</Eyebrow>
          <h2 className="mt-3 font-display font-bold text-4xl sm:text-5xl">
            5000 Nits. <span className="text-gradient">Blindingly Bright.</span>
          </h2>
          <p className="mt-5 text-slate-300">
            6.31-inch LTPO AMOLED with 1–120Hz adaptive refresh, 2640×1216
            resolution, P3 wide color, and 460 PPI.
          </p>
          <div className="mt-6 grid grid-cols-2 gap-3">
            <Stat label="Size" value={specs?.display?.size || '6.31"'} />
            <Stat label="Refresh" value="1-120Hz LTPO" />
            <Stat label="Peak" value="5000 nits" />
            <Stat label="Resolution" value="2640x1216" />
          </div>
        </div>
      </div>
    </Reveal>
  );
}

function Camera({ specs }: any) {
  return (
    <Reveal id="camera">
      <div className="text-center max-w-3xl mx-auto">
        <Eyebrow>04 · Camera</Eyebrow>
        <h2 className="mt-3 font-display font-bold text-4xl sm:text-5xl">
          A Studio in Your Pocket
        </h2>
        <p className="mt-5 text-slate-300">
          50MP main, 8MP ultrawide, 50MP telephoto. 4K/8K recording. Portrait,
          Night, Panorama, Street, Food, Time-lapse and more.
        </p>
        <div className="mt-10 grid sm:grid-cols-3 gap-4">
          <CamCard icon={CameraIcon} title="50MP Main" sub="f/1.57" />
          <CamCard icon={CameraIcon} title="8MP Ultrawide" sub="f/2.2" />
          <CamCard icon={CameraIcon} title="50MP Telephoto" sub="f/2.65" />
        </div>
      </div>
    </Reveal>
  );
}

function AI() {
  return (
    <Reveal id="ai">
      <div className="relative glass-strong rounded-3xl p-10 sm:p-16 text-center overflow-hidden">
        <div className="absolute -top-20 -left-20 w-80 h-80 rounded-full bg-accent-purple/20 blur-[100px]" />
        <div className="absolute -bottom-20 -right-20 w-80 h-80 rounded-full bg-accent-cyan/20 blur-[100px]" />
        <Eyebrow>05 · AI</Eyebrow>
        <h2 className="mt-3 font-display font-bold text-4xl sm:text-5xl">
          AI That Understands You
        </h2>
        <p className="mt-5 text-slate-300 max-w-2xl mx-auto">
          On-device generative AI for photo editing, real-time translation,
          smart search, and contextual assistance — all powered by the
          Snapdragon 8 Gen 5 NPU.
        </p>
      </div>
    </Reveal>
  );
}

function Processor({ specs }: any) {
  return (
    <Reveal id="processor">
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div>
          <Eyebrow>06 · Processor & Gaming</Eyebrow>
          <h2 className="mt-3 font-display font-bold text-4xl sm:text-5xl">
            Snapdragon 8 Gen 5
          </h2>
          <p className="mt-5 text-slate-300">
            3nm process. Octa-core CPU. Console-grade GPU. Sustained performance
            for the most demanding games.
          </p>
          <div className="mt-6 grid grid-cols-2 gap-3">
            <Stat label="Process" value="3nm" />
            <Stat label="CPU" value="Octa-core" />
            <Stat label="RAM" value={specs?.memory?.ram || '12GB LPDDR5X'} />
            <Stat label="Storage" value={specs?.memory?.storage || '256GB UFS 4.1'} />
          </div>
        </div>
        <motion.div
          initial={{ opacity: 0, rotate: -8 }}
          whileInView={{ opacity: 1, rotate: 0 }}
          viewport={{ once: true }}
          className="relative grid place-items-center"
        >
          <div className="w-48 h-48 rounded-3xl bg-gradient-to-br from-accent-cyan to-accent-purple grid place-items-center shadow-glow">
            <Cpu className="w-20 h-20 text-ink-950" />
          </div>
        </motion.div>
      </div>
    </Reveal>
  );
}

function Battery({ specs }: any) {
  return (
    <Reveal id="battery">
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="relative grid place-items-center order-2 md:order-1"
        >
          <div className="w-48 h-48 rounded-3xl bg-gradient-to-br from-accent-purple to-accent-cyan grid place-items-center shadow-glowPurple">
            <BatteryIcon className="w-20 h-20 text-ink-950" />
          </div>
        </motion.div>
        <div className="order-1 md:order-2">
          <Eyebrow>07 · Battery & Charging</Eyebrow>
          <h2 className="mt-3 font-display font-bold text-4xl sm:text-5xl">
            6500mAh. 90W Wired. 40W Wireless.
          </h2>
          <p className="mt-5 text-slate-300">
            A massive 6500mAh battery with 90W FlashCharge and 40W wireless
            charging. Power through two days on a single charge.
          </p>
        </div>
      </div>
    </Reveal>
  );
}

function Software({ specs }: any) {
  return (
    <Reveal id="software">
      <div className="text-center max-w-3xl mx-auto">
        <Eyebrow>08 · Software</Eyebrow>
        <h2 className="mt-3 font-display font-bold text-4xl sm:text-5xl">
          Android 16 · OriginOS 6
        </h2>
        <p className="mt-5 text-slate-300">
          A refined, fluid, and privacy-first software experience with
          long-term updates.
        </p>
      </div>
    </Reveal>
  );
}

function Connectivity({ specs }: any) {
  const items = [
    ['5G', 'Dual SIM Dual Standby'],
    ['Wi-Fi 6 & 7', 'Next-gen wireless'],
    ['Bluetooth 6.0', 'Low-latency audio'],
    ['NFC', 'Tap to pay'],
    ['GPS', 'BeiDou, GLONASS, Galileo, QZSS, NavIC'],
    ['USB 2.0', 'OTG support'],
  ];
  return (
    <Reveal id="connectivity">
      <div className="text-center">
        <Eyebrow>09 · Connectivity</Eyebrow>
        <h2 className="mt-3 font-display font-bold text-4xl sm:text-5xl">
          Always Connected
        </h2>
        <div className="mt-10 grid sm:grid-cols-3 gap-4">
          {items.map(([t, s]) => (
            <div key={t} className="glass rounded-2xl p-5">
              <Wifi className="w-6 h-6 text-accent-cyan mb-2" />
              <p className="font-medium">{t}</p>
              <p className="text-xs text-slate-400 mt-1">{s}</p>
            </div>
          ))}
        </div>
      </div>
    </Reveal>
  );
}

function Security({ specs }: any) {
  return (
    <Reveal id="security">
      <div className="text-center max-w-3xl mx-auto">
        <Eyebrow>10 · Security</Eyebrow>
        <h2 className="mt-3 font-display font-bold text-4xl sm:text-5xl">
          Secured to the Core
        </h2>
        <p className="mt-5 text-slate-300">
          3D ultrasonic fingerprint, secure enclave, and IP68/IP69 durability
          keep your data and your device safe.
        </p>
        <div className="mt-8 inline-flex items-center gap-2 glass rounded-full px-5 py-2.5">
          <Shield className="w-4 h-4 text-accent-cyan" /> IP68 & IP69 · 3D Ultrasonic Fingerprint
        </div>
      </div>
    </Reveal>
  );
}

function Specs({ specs }: any) {
  if (!specs) return null;
  const groups: [string, Record<string, string>][] = [
    ['Platform', specs.platform],
    ['Memory', specs.memory],
    ['Battery', specs.battery],
    ['Design', specs.design],
    ['Display', specs.display],
    ['Camera', specs.camera],
    ['Connectivity', specs.connectivity],
  ];
  return (
    <Reveal id="specs">
      <div className="text-center mb-10">
        <Eyebrow>11 · Full Specifications</Eyebrow>
        <h2 className="mt-3 font-display font-bold text-4xl sm:text-5xl">
          Every Detail
        </h2>
      </div>
      <div className="grid md:grid-cols-2 gap-5">
        {groups.map(([title, obj]) => (
          <div key={title} className="glass rounded-2xl p-6">
            <h3 className="font-display font-semibold text-lg mb-4 text-accent-cyan">
              {title}
            </h3>
            <div className="divide-y divide-white/5">
              {Object.entries(obj).map(([k, v]) => (
                <div key={k} className="flex justify-between py-2 text-sm">
                  <span className="text-slate-400 capitalize">{k.replace(/_/g, ' ')}</span>
                  <span className="text-slate-200 text-right">{v}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
        <div className="glass rounded-2xl p-6">
          <h3 className="font-display font-semibold text-lg mb-4 text-accent-cyan">Sensors</h3>
          <div className="flex flex-wrap gap-2">
            {specs.sensors.map((s: string) => (
              <span key={s} className="text-xs px-2.5 py-1 rounded-full glass">
                {s}
              </span>
            ))}
          </div>
        </div>
        <div className="glass rounded-2xl p-6">
          <h3 className="font-display font-semibold text-lg mb-4 text-accent-cyan">In the Box</h3>
          <ul className="space-y-2 text-sm">
            {specs.box_contents.map((b: string) => (
              <li key={b} className="flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" /> {b}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Reveal>
  );
}

function Gallery() {
  const images = [
    'https://images.pexels.com/photos/1294886/pexels-photo-1294886.jpeg',
    'https://images.pexels.com/photos/3568520/pexels-photo-3568520.jpeg',
    'https://images.pexels.com/photos/47261/pexels-photo-47261.jpeg',
    'https://images.pexels.com/photos/1841841/pexels-photo-1841841.jpeg',
  ];
  const [active, setActive] = useState(0);
  return (
    <Reveal id="gallery">
      <div className="text-center mb-10">
        <Eyebrow>12 · Gallery</Eyebrow>
        <h2 className="mt-3 font-display font-bold text-4xl sm:text-5xl">Gallery</h2>
      </div>
      <div className="grid lg:grid-cols-2 gap-6">
        <motion.div
          key={active}
          initial={{ opacity: 0.5, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative aspect-[4/3] rounded-3xl overflow-hidden glass"
        >
          <img src={images[active]} alt="" className="w-full h-full object-cover" />
        </motion.div>
        <div className="grid grid-cols-2 gap-4">
          {images.map((img, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className={`relative aspect-square rounded-2xl overflow-hidden border-2 transition-colors ${
                active === i ? 'border-accent-cyan' : 'border-transparent'
              }`}
            >
              <img src={img} alt="" className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      </div>
    </Reveal>
  );
}

function Compare({ specs }: any) {
  const rows: [string, string, string][] = [
    ['Display', '6.31" LTPO AMOLED 5000 nits', '6.7" AMOLED 2000 nits'],
    ['Processor', 'Snapdragon 8 Gen 5', 'Snapdragon 8 Gen 3'],
    ['Battery', '6500mAh · 90W', '5000mAh · 45W'],
    ['RAM', '12GB LPDDR5X', '12GB LPDDR5X'],
    ['Storage', '256GB UFS 4.1', '256GB UFS 4.0'],
    ['Camera', '50MP+8MP+50MP', '50MP+12MP+10MP'],
  ];
  return (
    <Reveal id="compare">
      <div className="text-center mb-10">
        <Eyebrow>13 · Comparison</Eyebrow>
        <h2 className="mt-3 font-display font-bold text-4xl sm:text-5xl">
          X300 FE vs The Rest
        </h2>
      </div>
      <div className="glass rounded-2xl overflow-hidden">
        <div className="grid grid-cols-3 bg-white/5 text-sm font-semibold">
          <div className="p-4">Spec</div>
          <div className="p-4 text-accent-cyan">vivo X300 FE</div>
          <div className="p-4 text-slate-400">Typical Flagship</div>
        </div>
        {rows.map(([s, a, b], i) => (
          <div
            key={s}
            className={`grid grid-cols-3 text-sm ${i % 2 ? 'bg-white/[0.02]' : ''}`}
          >
            <div className="p-4 text-slate-400">{s}</div>
            <div className="p-4 font-medium">{a}</div>
            <div className="p-4 text-slate-400">{b}</div>
          </div>
        ))}
      </div>
    </Reveal>
  );
}

function Reviews({ reviews }: any) {
  const sample = [
    { author: 'Ahmed Raza', rating: 5, body: 'The X300 FE is a beast. Battery lasts 2 days and camera is stunning.' },
    { author: 'Sana Khan', rating: 5, body: 'Display is gorgeous and 90W charging is incredibly fast.' },
    { author: 'Bilal Ahmed', rating: 4, body: 'Great phone overall, premium feel and excellent performance.' },
  ];
  const list = reviews?.length ? reviews : sample;
  return (
    <Reveal id="reviews">
      <div className="text-center mb-10">
        <Eyebrow>14 · Customer Reviews</Eyebrow>
        <h2 className="mt-3 font-display font-bold text-4xl sm:text-5xl">
          Loved by Early Adopters
        </h2>
      </div>
      <div className="grid md:grid-cols-3 gap-5">
        {list.slice(0, 3).map((r: any, i: number) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="glass rounded-2xl p-6"
          >
            <div className="flex text-amber-400 text-xs mb-2">
              {'★'.repeat(r.rating)}
            </div>
            <p className="text-sm text-slate-300">{r.body}</p>
            <p className="mt-4 text-sm font-medium">{r.author_name || r.author}</p>
          </motion.div>
        ))}
      </div>
    </Reveal>
  );
}

function FAQ({ specs }: any) {
  const faqs = (specs?.faqs as { q: string; a: string }[]) || [];
  const [open, setOpen] = useState<number | null>(0);
  return (
    <Reveal id="faq">
      <div className="text-center mb-10">
        <Eyebrow>15 · FAQ</Eyebrow>
        <h2 className="mt-3 font-display font-bold text-4xl sm:text-5xl">
          Frequently Asked
        </h2>
      </div>
      <div className="max-w-2xl mx-auto space-y-3">
        {faqs.map((f, i) => (
          <div key={i} className="glass rounded-2xl overflow-hidden">
            <button
              onClick={() => setOpen(open === i ? null : i)}
              className="w-full flex items-center justify-between p-5 text-left"
            >
              <span className="font-medium">{f.q}</span>
              <span className="text-accent-cyan text-xl">
                {open === i ? '−' : '+'}
              </span>
            </button>
            <motion.div
              initial={false}
              animate={{ height: open === i ? 'auto' : 0, opacity: open === i ? 1 : 0 }}
              className="overflow-hidden"
            >
              <p className="px-5 pb-5 text-sm text-slate-300">{f.a}</p>
            </motion.div>
          </div>
        ))}
      </div>
    </Reveal>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="glass rounded-xl p-3">
      <p className="text-xs text-slate-400">{label}</p>
      <p className="text-sm font-medium mt-0.5">{value}</p>
    </div>
  );
}

function CamCard({ icon: Icon, title, sub }: any) {
  return (
    <div className="glass rounded-2xl p-5 text-center">
      <Icon className="w-7 h-7 mx-auto text-accent-cyan mb-2" />
      <p className="font-medium">{title}</p>
      <p className="text-xs text-slate-400 mt-1">{sub}</p>
    </div>
  );
}
