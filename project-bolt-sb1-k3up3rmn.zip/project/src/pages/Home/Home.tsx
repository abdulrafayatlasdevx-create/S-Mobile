import { lazy, Suspense, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import {
  ChevronDown,
  ShieldCheck,
  Truck,
  Headphones,
  Award,
  Sparkles,
  ArrowRight,
  Quote,
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import MagneticButton from '../../components/common/MagneticButton';
import LoadingScreen from '../../components/common/LoadingScreen';
import ProductCard from '../../components/product/ProductCard';
import {
  useBrands,
  useOffers,
  useProducts,
  useReviews,
  useSettings,
} from '../../lib/hooks';
import { formatPKR } from '../../lib/utils';

const Hero3D = lazy(() => import('../../components/animations/Hero3D'));

export default function Home() {
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 1500);
    return () => clearTimeout(t);
  }, []);

  if (loading) return <LoadingScreen />;
  return (
    <>
      <Hero />
      <X300Launch />
      <Featured />
      <Brands />
      <Offers />
      <WhyChoose />
      <Reviews />
      <About />
      <Contact />
      <Newsletter />
    </>
  );
}

function Hero() {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 600], [0, 120]);
  const opacity = useTransform(scrollY, [0, 400], [1, 0]);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background grid + glow */}
      <div className="absolute inset-0 bg-grid-faint bg-grid opacity-30" />
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-accent-purple/20 blur-[120px]" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] rounded-full bg-accent-cyan/15 blur-[120px]" />

      <motion.div style={{ y, opacity }} className="relative z-10 text-center px-6 max-w-4xl">
        <motion.span
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass text-xs uppercase tracking-widest text-accent-cyan mb-6"
        >
          <Sparkles className="w-3.5 h-3.5" /> Premium Mobile Store · Since 2004
        </motion.span>
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.7 }}
          className="font-display font-bold text-5xl sm:text-7xl lg:text-8xl leading-[1.05] tracking-tight"
        >
          The Future of <br />
          <span className="text-gradient">Mobile Shopping</span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-6 text-lg text-slate-300 max-w-2xl mx-auto"
        >
          Discover the vivo X300 FE and the world's finest smartphones in a
          cinematic, immersive experience crafted for you.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="mt-9 flex flex-wrap items-center justify-center gap-4"
        >
          <Link to="/products/x300-fe">
            <MagneticButton size="lg">
              Explore X300 FE <ArrowRight className="w-4 h-4" />
            </MagneticButton>
          </Link>
          <Link to="/products">
            <MagneticButton size="lg" variant="outline">
              Shop All
            </MagneticButton>
          </Link>
        </motion.div>
      </motion.div>

      {/* 3D phone */}
      <div className="absolute inset-0 z-0 pointer-events-none opacity-90">
        <Suspense fallback={null}>
          <Hero3D />
        </Suspense>
      </div>

      {/* Scroll cue */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-slate-400"
      >
        <span className="text-[10px] uppercase tracking-widest">Scroll</span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.6, repeat: Infinity }}
        >
          <ChevronDown className="w-5 h-5" />
        </motion.div>
      </motion.div>
    </section>
  );
}

function SectionHeader({
  eyebrow,
  title,
  subtitle,
}: {
  eyebrow: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-80px' }}
      transition={{ duration: 0.6 }}
      className="text-center max-w-2xl mx-auto mb-12"
    >
      <span className="text-xs uppercase tracking-widest text-accent-cyan">
        {eyebrow}
      </span>
      <h2 className="mt-3 font-display font-bold text-3xl sm:text-5xl tracking-tight">
        {title}
      </h2>
      {subtitle && <p className="mt-3 text-slate-400">{subtitle}</p>}
    </motion.div>
  );
}

function X300Launch() {
  return (
    <section className="relative py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.8 }}
          className="relative overflow-hidden rounded-3xl glass-strong p-8 sm:p-14"
        >
          <div className="absolute -top-20 -right-20 w-80 h-80 rounded-full bg-accent-cyan/20 blur-[100px]" />
          <div className="absolute -bottom-20 -left-20 w-80 h-80 rounded-full bg-accent-purple/20 blur-[100px]" />
          <div className="relative grid md:grid-cols-2 gap-10 items-center">
            <div>
              <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold uppercase tracking-wider">
                New Arrival · Available Now
              </span>
              <h2 className="mt-5 font-display font-bold text-4xl sm:text-6xl leading-[1.05]">
                vivo <span className="text-gradient">X300 FE</span>
              </h2>
              <p className="mt-4 text-slate-300 max-w-md">
                Snapdragon 8 Gen 5 · 6500mAh · 50MP triple camera · 5000-nit LTPO
                AMOLED. The cinematic flagship.
              </p>
              <div className="mt-6 flex items-center gap-4">
                <span className="text-3xl font-bold font-display">
                  {formatPKR(269999)}
                </span>
                <span className="text-slate-500 line-through">
                  {formatPKR(289999)}
                </span>
              </div>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link to="/products/x300-fe">
                  <MagneticButton>
                    Learn More <ArrowRight className="w-4 h-4" />
                  </MagneticButton>
                </Link>
                <Link to="/products/x300-fe">
                  <MagneticButton variant="outline">Buy Now</MagneticButton>
                </Link>
              </div>
            </div>
            <div className="relative">
              <motion.img
                src="https://images.pexels.com/photos/1294886/pexels-photo-1294886.jpeg"
                alt="vivo X300 FE"
                className="rounded-2xl w-full aspect-square object-cover"
                animate={{ y: [0, -12, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
              />
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-tr from-accent-cyan/30 to-accent-purple/30 mix-blend-overlay" />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function Featured() {
  const { products, loading } = useProducts({ featured: true });
  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <SectionHeader
          eyebrow="Featured"
          title="Featured Products"
          subtitle="Handpicked flagship devices and accessories."
        />
        {loading ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="skeleton rounded-2xl aspect-[4/5]" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
            {products.slice(0, 8).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function Brands() {
  const brands = useBrands();
  return (
    <section className="py-16 px-6">
      <div className="max-w-7xl mx-auto">
        <SectionHeader eyebrow="Top Brands" title="Brands We Carry" />
        <div className="flex flex-wrap items-center justify-center gap-4">
          {brands.map((b, i) => (
            <motion.div
              key={b.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              whileHover={{ y: -4 }}
              className="glass rounded-2xl px-8 py-6 min-w-[140px] text-center"
            >
              <span className="font-display font-semibold text-lg">{b.name}</span>
              {b.country && (
                <p className="text-xs text-slate-400 mt-1">{b.country}</p>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Offers() {
  const offers = useOffers();
  if (offers.length === 0) return null;
  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <SectionHeader eyebrow="Latest Offers" title="Save More Today" />
        <div className="grid md:grid-cols-3 gap-6">
          {offers.map((o, i) => (
            <motion.div
              key={o.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -6 }}
              className="group relative glass rounded-2xl overflow-hidden p-6"
            >
              <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-accent-cyan/15 blur-3xl group-hover:bg-accent-purple/20 transition-colors" />
              {o.badge && (
                <span className="inline-block px-3 py-1 rounded-full bg-gradient-to-r from-accent-cyan to-accent-purple text-ink-950 text-xs font-bold uppercase tracking-wider">
                  {o.badge}
                </span>
              )}
              <h3 className="mt-4 font-display font-bold text-2xl">{o.title}</h3>
              <p className="mt-2 text-slate-400">{o.subtitle}</p>
              <Link
                to={o.cta_link || '/products'}
                className="mt-5 inline-flex items-center gap-2 text-accent-cyan text-sm font-medium hover:gap-3 transition-all"
              >
                {o.cta_text || 'Shop Now'} <ArrowRight className="w-4 h-4" />
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function WhyChoose() {
  const items = [
    { icon: ShieldCheck, title: 'Official Warranty', text: 'Genuine products with official warranty.' },
    { icon: Truck, title: 'Fast Delivery', text: 'Nationwide shipping & in-store pickup.' },
    { icon: Headphones, title: 'Expert Support', text: 'Personal assistance on WhatsApp & call.' },
    { icon: Award, title: 'Trusted Since 2004', text: 'Two decades of satisfied customers.' },
  ];
  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <SectionHeader
          eyebrow="Why S Mobile"
          title="Why Choose S Mobile"
          subtitle="Built on trust, expertise, and a passion for technology."
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {items.map((it, i) => (
            <motion.div
              key={it.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass rounded-2xl p-6 text-center hover:glow-ring transition-shadow"
            >
              <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-br from-accent-cyan/20 to-accent-purple/20 grid place-items-center mb-4">
                <it.icon className="w-6 h-6 text-accent-cyan" />
              </div>
              <h3 className="font-semibold">{it.title}</h3>
              <p className="text-sm text-slate-400 mt-2">{it.text}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Reviews() {
  const { reviews, loading } = useReviews(undefined);
  // fallback: fetch reviews for first featured product
  const { products } = useProducts({ featured: true });
  const [list, setList] = useState<typeof reviews>([]);
  useEffect(() => {
    if (products[0]) {
      // simple inline fetch
        supabase
          .from('reviews')
          .select('*')
          .eq('approved', true)
          .order('created_at', { ascending: false })
          .limit(6)
          .then(({ data }) => data && setList(data as any));
    }
  }, [products]);
  const shown = list.length ? list : reviews;
  if (loading && shown.length === 0) return null;
  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <SectionHeader
          eyebrow="Reviews"
          title="What Customers Say"
          subtitle="Real feedback from our community."
        />
        <div className="grid md:grid-cols-3 gap-5">
          {shown.slice(0, 6).map((r, i) => (
            <motion.div
              key={r.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="glass rounded-2xl p-6"
            >
              <Quote className="w-7 h-7 text-accent-cyan/60 mb-3" />
              <p className="text-sm text-slate-300 leading-relaxed">{r.body}</p>
              <div className="mt-5 flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-accent-cyan to-accent-purple grid place-items-center text-ink-950 font-bold text-sm">
                  {(r.author_name || 'A')[0]}
                </div>
                <div>
                  <p className="text-sm font-medium">{r.author_name || 'Anonymous'}</p>
                  <div className="flex text-amber-400 text-xs">
                    {'★'.repeat(r.rating)}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section className="py-24 px-6">
      <div className="max-w-5xl mx-auto text-center">
        <SectionHeader eyebrow="Our Story" title="About S Mobile" />
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-lg text-slate-300 leading-relaxed"
        >
          Founded in 2004 by <strong>Sajid Qureshi (Advocate)</strong> and{' '}
          <strong>Shakeel Qureshi</strong>, S Mobile has grown into Shujaabad's
          most trusted destination for premium mobile devices. For two decades,
          we've combined genuine products, expert guidance, and honest pricing
          to serve our community.
        </motion.p>
        <div className="mt-10 grid sm:grid-cols-3 gap-5">
          {[
            ['20+', 'Years of Service'],
            ['10k+', 'Happy Customers'],
            ['50+', 'Products in Store'],
          ].map(([n, l]) => (
            <motion.div
              key={l}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="glass rounded-2xl p-6"
            >
              <p className="text-4xl font-display font-bold text-gradient">{n}</p>
              <p className="text-sm text-slate-400 mt-1">{l}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Contact() {
  const settings = useSettings();
  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-10 items-stretch">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="glass rounded-3xl p-8 sm:p-12"
        >
          <SectionHeader eyebrow="Visit Us" title="Contact & Location" />
          <div className="space-y-4 text-slate-300">
            <p>{settings?.address}</p>
            <div className="flex flex-col gap-2">
              <span className="text-accent-cyan text-sm uppercase tracking-widest">
                Owners
              </span>
              <p>Sajid Qureshi (Advocate) — {settings?.contact_phone1} / {settings?.contact_phone2}</p>
              <p>Shakeel Qureshi — {settings?.contact_phone3}</p>
            </div>
            <a
              href={`https://wa.me/${settings?.whatsapp || '923017504004'}`}
              target="_blank"
              rel="noreferrer"
              className="inline-block mt-4"
            >
              <MagneticButton>
                Message on WhatsApp <ArrowRight className="w-4 h-4" />
              </MagneticButton>
            </a>
          </div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="rounded-3xl overflow-hidden min-h-[360px] glass"
        >
          <iframe
            title="S Mobile Location"
            src="https://www.google.com/maps?q=Shujaabad,Pakistan&output=embed"
            className="w-full h-full min-h-[360px] grayscale-[0.3] contrast-110"
            loading="lazy"
          />
        </motion.div>
      </div>
    </section>
  );
}

function Newsletter() {
  return (
    <section className="py-24 px-6">
      <div className="max-w-3xl mx-auto text-center">
        <SectionHeader
          eyebrow="Newsletter"
          title="Stay in the Loop"
          subtitle="Get launch alerts, offers, and exclusive deals."
        />
        <form
          onSubmit={(e) => e.preventDefault()}
          className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto"
        >
          <input
            type="email"
            required
            placeholder="you@email.com"
            className="flex-1 glass rounded-full px-5 py-3 outline-none focus:glow-ring transition-shadow"
          />
          <MagneticButton type="submit">Subscribe</MagneticButton>
        </form>
      </div>
    </section>
  );
}
