import { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  LayoutDashboard,
  Package,
  Image,
  ShoppingCart,
  Users,
  Star,
  Settings as SettingsIcon,
  Plus,
  Pencil,
  Trash2,
  X,
} from 'lucide-react';
import { useAuth } from '../../store/auth';
import { supabase } from '../../lib/supabase';
import { useBrands, useCategories, useProducts } from '../../lib/hooks';
import type { Product } from '../../lib/types';
import { formatPKR, slugify } from '../../lib/utils';
import { useToast } from '../../store/toast';

const TABS = [
  { key: 'overview', label: 'Overview', icon: LayoutDashboard },
  { key: 'products', label: 'Products', icon: Package },
  { key: 'orders', label: 'Orders', icon: ShoppingCart },
  { key: 'customers', label: 'Customers', icon: Users },
  { key: 'reviews', label: 'Reviews', icon: Star },
  { key: 'banners', label: 'Banners', icon: Image },
  { key: 'settings', label: 'Settings', icon: SettingsIcon },
];

export default function Admin() {
  const { user, profile, loading } = useAuth();
  const [tab, setTab] = useState('overview');

  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  if (profile && profile.role !== 'admin' && profile.role !== 'super_admin')
    return (
      <div className="pt-32 px-6 text-center min-h-screen">
        <h1 className="text-2xl font-bold">Admins only</h1>
        <p className="text-slate-400 mt-2">
          Your account does not have admin privileges.
        </p>
      </div>
    );

  return (
    <div className="pt-24 pb-24 px-6 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <h1 className="font-display font-bold text-3xl sm:text-4xl mb-8">
          Admin Dashboard
        </h1>
        <div className="grid lg:grid-cols-[240px_1fr] gap-6">
          <aside className="glass rounded-2xl p-3 h-fit">
            <nav className="flex lg:flex-col gap-1 overflow-x-auto">
              {TABS.map((t) => (
                <button
                  key={t.key}
                  onClick={() => setTab(t.key)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm whitespace-nowrap transition-colors ${
                    tab === t.key
                      ? 'bg-white/10 text-accent-cyan'
                      : 'text-slate-300 hover:bg-white/5'
                  }`}
                >
                  <t.icon className="w-4 h-4" /> {t.label}
                </button>
              ))}
            </nav>
          </aside>
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass rounded-2xl p-6"
          >
            {tab === 'overview' && <Overview />}
            {tab === 'products' && <ProductsAdmin />}
            {tab === 'orders' && <OrdersAdmin />}
            {tab === 'customers' && <Customers />}
            {tab === 'reviews' && <ReviewsAdmin />}
            {tab === 'banners' && <Banners />}
            {tab === 'settings' && <SettingsAdmin />}
          </motion.div>
        </div>
      </div>
    </div>
  );
}

function Overview() {
  const { products } = useProducts();
  const [orders, setOrders] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  useEffect(() => {
    supabase.from('orders').select('id,total,status').then(({ data }) => setOrders(data || []));
    supabase.from('profiles').select('id,role,created_at').then(({ data }) => setUsers(data || []));
  }, []);
  const revenue = (orders as any[]).reduce((s, o) => s + Number(o.total || 0), 0);
  const lowStock = products.filter((p) => p.stock < 5);

  const cards = [
    ['Revenue', formatPKR(revenue), 'from-accent-cyan to-accent-purple'],
    ['Orders', String(orders.length || 0), 'from-emerald-400 to-teal-500'],
    ['Products', String(products.length), 'from-violet-400 to-fuchsia-500'],
    ['Customers', String(users.length || 0), 'from-amber-400 to-orange-500'],
  ];
  return (
    <div>
      <h2 className="font-display font-bold text-2xl mb-6">Overview</h2>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map(([label, value, grad]) => (
          <div key={label} className="glass rounded-2xl p-5">
            <p className="text-xs text-slate-400 uppercase tracking-widest">{label}</p>
            <p className={`mt-2 text-2xl font-bold bg-gradient-to-r ${grad} bg-clip-text text-transparent`}>
              {value}
            </p>
          </div>
        ))}
      </div>
      <div className="mt-6">
        <h3 className="font-semibold mb-3">Low-stock alerts</h3>
        {lowStock.length === 0 ? (
          <p className="text-slate-400 text-sm">All products well stocked.</p>
        ) : (
          <div className="space-y-2">
            {lowStock.map((p) => (
              <div key={p.id} className="glass rounded-xl p-3 flex justify-between text-sm">
                <span>{p.name}</span>
                <span className="text-rose-400">{p.stock} left</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ProductsAdmin() {
  const { products, loading } = useProducts();
  const brands = useBrands();
  const categories = useCategories();
  const { push } = useToast();
  const [editing, setEditing] = useState<Product | null>(null);
  const [creating, setCreating] = useState(false);

  const blank: Partial<Product> = {
    name: '',
    slug: '',
    price: 0,
    compare_price: 0,
    stock: 0,
    images: [],
    short_description: '',
    description: '',
    is_featured: false,
    is_published: true,
    tags: [],
    variants: {},
    specs: {},
  };

  const del = async (id: string) => {
    if (!confirm('Delete this product?')) return;
    await supabase.from('products').delete().eq('id', id);
    push('Product deleted', 'info');
    location.reload();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-display font-bold text-2xl">Products</h2>
        <button
          onClick={() => setCreating(true)}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-accent-cyan to-accent-purple text-ink-950 text-sm font-semibold"
        >
          <Plus className="w-4 h-4" /> Add Product
        </button>
      </div>
      {loading ? (
        <p className="text-slate-400">Loading...</p>
      ) : (
        <div className="space-y-2">
          {products.map((p) => (
            <div key={p.id} className="glass rounded-xl p-3 flex items-center gap-3">
              <img src={p.images[0]} alt="" className="w-12 h-12 rounded-lg object-cover" />
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">{p.name}</p>
                <p className="text-xs text-slate-400">
                  {formatPKR(p.price)} · Stock: {p.stock} · {p.is_featured ? 'Featured' : 'Standard'}
                </p>
              </div>
              <button onClick={() => setEditing(p)} className="w-9 h-9 rounded-full glass grid place-items-center">
                <Pencil className="w-4 h-4" />
              </button>
              <button onClick={() => del(p.id)} className="w-9 h-9 rounded-full glass grid place-items-center text-rose-400">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
      {(editing || creating) && (
        <ProductEditor
          product={editing || (blank as Product)}
          brands={brands}
          categories={categories}
          onClose={() => {
            setEditing(null);
            setCreating(false);
          }}
          onSaved={() => {
            setEditing(null);
            setCreating(false);
            location.reload();
          }}
        />
      )}
    </div>
  );
}

function ProductEditor({ product, brands, categories, onClose, onSaved }: any) {
  const { push } = useToast();
  const [form, setForm] = useState<any>({
    ...product,
    brand_id: product.brand_id || brands[0]?.id,
    category_id: product.category_id || categories[0]?.id,
    images_text: (product.images || []).join(', '),
    tags_text: (product.tags || []).join(', '),
  });

  const save = async () => {
    const payload = {
      name: form.name,
      slug: form.slug || slugify(form.name),
      brand_id: form.brand_id,
      category_id: form.category_id,
      short_description: form.short_description,
      description: form.description,
      price: Number(form.price),
      compare_price: Number(form.compare_price) || null,
      stock: Number(form.stock),
      images: form.images_text.split(',').map((s: string) => s.trim()).filter(Boolean),
      tags: form.tags_text.split(',').map((s: string) => s.trim()).filter(Boolean),
      is_featured: !!form.is_featured,
      is_published: !!form.is_published,
      variants: form.variants || {},
      specs: form.specs || {},
    };
    const { error } = product.id
      ? await supabase.from('products').update(payload).eq('id', product.id)
      : await supabase.from('products').insert(payload);
    if (error) push(error.message, 'error');
    else {
      push('Product saved');
      onSaved();
    }
  };

  return (
    <div className="fixed inset-0 z-[200] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="glass-strong rounded-3xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display font-bold text-xl">
            {product.id ? 'Edit Product' : 'New Product'}
          </h3>
          <button onClick={onClose} className="w-9 h-9 rounded-full glass grid place-items-center">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="space-y-3 text-sm">
          <Input label="Name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} />
          <Input label="Slug (auto)" value={form.slug} onChange={(v) => setForm({ ...form, slug: v })} />
          <div className="grid grid-cols-2 gap-3">
            <Select label="Brand" value={form.brand_id} onChange={(v) => setForm({ ...form, brand_id: v })}
              options={brands.map((b: any) => ({ value: b.id, label: b.name }))} />
            <Select label="Category" value={form.category_id} onChange={(v) => setForm({ ...form, category_id: v })}
              options={categories.map((c: any) => ({ value: c.id, label: c.name }))} />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Input label="Price" type="number" value={form.price} onChange={(v) => setForm({ ...form, price: v })} />
            <Input label="Compare" type="number" value={form.compare_price} onChange={(v) => setForm({ ...form, compare_price: v })} />
            <Input label="Stock" type="number" value={form.stock} onChange={(v) => setForm({ ...form, stock: v })} />
          </div>
          <Input label="Short description" value={form.short_description} onChange={(v) => setForm({ ...form, short_description: v })} />
          <TextArea label="Description" value={form.description} onChange={(v) => setForm({ ...form, description: v })} />
          <TextArea label="Image URLs (comma separated)" value={form.images_text} onChange={(v) => setForm({ ...form, images_text: v })} />
          <Input label="Tags (comma separated)" value={form.tags_text} onChange={(v) => setForm({ ...form, tags_text: v })} />
          <div className="flex gap-4">
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={form.is_featured} onChange={(e) => setForm({ ...form, is_featured: e.target.checked })} className="accent-accent-cyan" />
              Featured
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={form.is_published} onChange={(e) => setForm({ ...form, is_published: e.target.checked })} className="accent-accent-cyan" />
              Published
            </label>
          </div>
          <button
            onClick={save}
            className="w-full py-3 rounded-full bg-gradient-to-r from-accent-cyan to-accent-purple text-ink-950 font-semibold"
          >
            Save Product
          </button>
        </div>
      </div>
    </div>
  );
}

function OrdersAdmin() {
  const [orders, setOrders] = useState<any[]>([]);
  useEffect(() => {
    supabase.from('orders').select('*').order('created_at', { ascending: false }).then(({ data }) => setOrders(data || []));
  }, []);
  return (
    <div>
      <h2 className="font-display font-bold text-2xl mb-6">Orders</h2>
      {orders.length === 0 ? (
        <p className="text-slate-400">No orders yet.</p>
      ) : (
        <div className="space-y-2">
          {orders.map((o) => (
            <div key={o.id} className="glass rounded-xl p-3 flex justify-between text-sm">
              <span>#{o.id.slice(0, 8)} · {new Date(o.created_at).toLocaleDateString()}</span>
              <span className="text-accent-cyan">{o.status}</span>
              <span className="font-medium">{formatPKR(o.total)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function Customers() {
  const [users, setUsers] = useState<any[]>([]);
  useEffect(() => {
    supabase.from('profiles').select('*').order('created_at', { ascending: false }).then(({ data }) => setUsers(data || []));
  }, []);
  return (
    <div>
      <h2 className="font-display font-bold text-2xl mb-6">Customers</h2>
      {users.length === 0 ? (
        <p className="text-slate-400">No registered customers.</p>
      ) : (
        <div className="space-y-2">
          {users.map((u) => (
            <div key={u.id} className="glass rounded-xl p-3 flex justify-between text-sm">
              <span>{u.full_name || 'Unnamed'}</span>
              <span className="text-slate-400">{u.role}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ReviewsAdmin() {
  const [reviews, setReviews] = useState<any[]>([]);
  useEffect(() => {
    supabase.from('reviews').select('*,products(name)').order('created_at', { ascending: false }).then(({ data }) => setReviews(data || []));
  }, []);
  return (
    <div>
      <h2 className="font-display font-bold text-2xl mb-6">Reviews</h2>
      {reviews.length === 0 ? (
        <p className="text-slate-400">No reviews.</p>
      ) : (
        <div className="space-y-2">
          {reviews.map((r) => (
            <div key={r.id} className="glass rounded-xl p-3 text-sm">
              <p className="font-medium">{r.author_name} · {r.products?.name}</p>
              <p className="text-slate-400 mt-1">{r.body}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function Banners() {
  const [offers, setOffers] = useState<any[]>([]);
  const { push } = useToast();
  useEffect(() => {
    supabase.from('offers').select('*').order('sort_order').then(({ data }) => setOffers(data || []));
  }, []);
  const toggle = async (o: any) => {
    await supabase.from('offers').update({ active: !o.active }).eq('id', o.id);
    setOffers((prev) => prev.map((x) => (x.id === o.id ? { ...x, active: !x.active } : x)));
    push('Offer updated');
  };
  return (
    <div>
      <h2 className="font-display font-bold text-2xl mb-6">Banners & Offers</h2>
      <div className="space-y-2">
        {offers.map((o) => (
          <div key={o.id} className="glass rounded-xl p-3 flex justify-between items-center text-sm">
            <div>
              <p className="font-medium">{o.title}</p>
              <p className="text-xs text-slate-400">{o.subtitle}</p>
            </div>
            <button
              onClick={() => toggle(o)}
              className={`px-3 py-1 rounded-full text-xs ${o.active ? 'bg-emerald-500/20 text-emerald-300' : 'bg-white/5 text-slate-400'}`}
            >
              {o.active ? 'Active' : 'Inactive'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function SettingsAdmin() {
  const { push } = useToast();
  const [s, setS] = useState<any>(null);
  useEffect(() => {
    supabase.from('settings').select('*').eq('id', 1).maybeSingle().then(({ data }) => setS(data));
  }, []);
  if (!s) return <p>Loading...</p>;
  const save = async () => {
    await supabase.from('settings').update({
      store_name: s.store_name,
      accent_primary: s.accent_primary,
      accent_secondary: s.accent_secondary,
      contact_phone1: s.contact_phone1,
      contact_phone2: s.contact_phone2,
      contact_phone3: s.contact_phone3,
      address: s.address,
      whatsapp: s.whatsapp,
    }).eq('id', 1);
    push('Settings saved');
  };
  return (
    <div>
      <h2 className="font-display font-bold text-2xl mb-6">Store Settings</h2>
      <div className="space-y-3 max-w-md">
        <Input label="Store name" value={s.store_name} onChange={(v) => setS({ ...s, store_name: v })} />
        <Input label="Accent primary" value={s.accent_primary} onChange={(v) => setS({ ...s, accent_primary: v })} />
        <Input label="Accent secondary" value={s.accent_secondary} onChange={(v) => setS({ ...s, accent_secondary: v })} />
        <Input label="Phone 1" value={s.contact_phone1} onChange={(v) => setS({ ...s, contact_phone1: v })} />
        <Input label="Phone 2" value={s.contact_phone2} onChange={(v) => setS({ ...s, contact_phone2: v })} />
        <Input label="Phone 3" value={s.contact_phone3} onChange={(v) => setS({ ...s, contact_phone3: v })} />
        <Input label="WhatsApp" value={s.whatsapp} onChange={(v) => setS({ ...s, whatsapp: v })} />
        <TextArea label="Address" value={s.address} onChange={(v) => setS({ ...s, address: v })} />
        <button onClick={save} className="px-6 py-2.5 rounded-full bg-gradient-to-r from-accent-cyan to-accent-purple text-ink-950 font-semibold text-sm">
          Save Settings
        </button>
      </div>
    </div>
  );
}

function Input({ label, value, onChange, type = 'text' }: { label: string; value: any; onChange: (v: string) => void; type?: string }) {
  return (
    <div>
      <label className="text-xs text-slate-400 uppercase tracking-widest">{label}</label>
      <input
        type={type}
        value={value || ''}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full glass rounded-xl px-4 py-2.5 outline-none text-sm"
      />
    </div>
  );
}

function TextArea({ label, value, onChange }: { label: string; value: any; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="text-xs text-slate-400 uppercase tracking-widest">{label}</label>
      <textarea
        value={value || ''}
        onChange={(e) => onChange(e.target.value)}
        rows={3}
        className="mt-1 w-full glass rounded-xl px-4 py-2.5 outline-none text-sm resize-none"
      />
    </div>
  );
}

function Select({ label, value, onChange, options }: { label: string; value: any; onChange: (v: string) => void; options: { value: string; label: string }[] }) {
  return (
    <div>
      <label className="text-xs text-slate-400 uppercase tracking-widest">{label}</label>
      <select
        value={value || ''}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full glass rounded-xl px-4 py-2.5 outline-none text-sm bg-ink-900"
      >
        {options.map((o: any) => (
          <option key={o.value} value={o.value}>{o.label}</option>
        ))}
      </select>
    </div>
  );
}
