import { motion } from 'framer-motion';
import { Award, Users, MapPin, Sparkles } from 'lucide-react';
import { useSettings } from '../../lib/hooks';

export default function About() {
  const settings = useSettings();
  return (
    <div className="pt-24 pb-24 px-6">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <span className="text-xs uppercase tracking-widest text-accent-cyan">
            Since 2004
          </span>
          <h1 className="mt-3 font-display font-bold text-5xl sm:text-6xl">
            About <span className="text-gradient">S Mobile</span>
          </h1>
          <p className="mt-5 text-lg text-slate-300 max-w-2xl mx-auto">
            Two decades of trust, expertise, and premium mobile experiences in
            the heart of Shujaabad.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass rounded-3xl p-8"
          >
            <h2 className="font-display font-bold text-2xl mb-4">Our Founders</h2>
            <div className="space-y-4">
              <div>
                <p className="font-semibold">Sajid Qureshi (Advocate)</p>
                <p className="text-sm text-slate-400 mt-1">
                  {settings?.contact_phone1} / {settings?.contact_phone2}
                </p>
              </div>
              <div>
                <p className="font-semibold">Shakeel Qureshi</p>
                <p className="text-sm text-slate-400 mt-1">
                  {settings?.contact_phone3}
                </p>
              </div>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass rounded-3xl p-8"
          >
            <MapPin className="w-6 h-6 text-accent-cyan mb-3" />
            <h2 className="font-display font-bold text-2xl mb-3">Visit Us</h2>
            <p className="text-slate-300">{settings?.address}</p>
          </motion.div>
        </div>

        <div className="grid sm:grid-cols-3 gap-5">
          {[
            [Award, '20+ Years', 'Of trusted service'],
            [Users, '10k+ Customers', 'Satisfied & returning'],
            [Sparkles, 'Premium Selection', 'Only the best brands'],
          ].map(([Icon, title, sub], i) => (
            <motion.div
              key={title as string}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass rounded-2xl p-6 text-center"
            >
              {/* @ts-ignore */}
              <Icon className="w-8 h-8 mx-auto text-accent-cyan mb-3" />
              <p className="font-display font-bold text-xl">{title as string}</p>
              <p className="text-sm text-slate-400 mt-1">{sub as string}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
