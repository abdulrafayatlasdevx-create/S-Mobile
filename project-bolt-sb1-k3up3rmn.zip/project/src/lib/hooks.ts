import { useEffect, useState } from 'react';
import { supabase } from './supabase';
import type {
  Brand,
  Category,
  Offer,
  Product,
  Review,
  Settings,
  X300Specs,
} from './types';

export function useProducts(filters?: {
  category?: string;
  brand?: string;
  search?: string;
  featured?: boolean;
}) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let q = supabase
      .from('products')
      .select('*, brands(name,slug), categories(name,slug)')
      .eq('is_published', true)
      .order('created_at', { ascending: false });
    if (filters?.category) q = q.eq('categories.slug', filters.category);
    if (filters?.brand) q = q.eq('brands.slug', filters.brand);
    if (filters?.featured) q = q.eq('is_featured', true);
    if (filters?.search) {
      q = q.or(
        `name.ilike.%${filters.search}%,short_description.ilike.%${filters.search}%`
      );
    }
    q.then(({ data, error }) => {
      if (!error && data) setProducts(data as unknown as Product[]);
      setLoading(false);
    });
  }, [filters?.category, filters?.brand, filters?.featured, filters?.search]);

  return { products, loading };
}

export function useProduct(slug: string) {
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from('products')
      .select('*, brands(name,slug), categories(name,slug)')
      .eq('slug', slug)
      .maybeSingle()
      .then(({ data, error }) => {
        if (!error && data) setProduct(data as unknown as Product);
        setLoading(false);
      });
  }, [slug]);

  return { product, loading };
}

export function useBrands() {
  const [brands, setBrands] = useState<Brand[]>([]);
  useEffect(() => {
    supabase
      .from('brands')
      .select('*')
      .order('name')
      .then(({ data }) => data && setBrands(data as Brand[]));
  }, []);
  return brands;
}

export function useCategories() {
  const [cats, setCats] = useState<Category[]>([]);
  useEffect(() => {
    supabase
      .from('categories')
      .select('*')
      .order('name')
      .then(({ data }) => data && setCats(data as Category[]));
  }, []);
  return cats;
}

export function useOffers() {
  const [offers, setOffers] = useState<Offer[]>([]);
  useEffect(() => {
    supabase
      .from('offers')
      .select('*')
      .eq('active', true)
      .order('sort_order')
      .then(({ data }) => data && setOffers(data as Offer[]));
  }, []);
  return offers;
}

export function useReviews(productId: string | undefined) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (!productId) return;
    supabase
      .from('reviews')
      .select('*')
      .eq('product_id', productId)
      .eq('approved', true)
      .order('created_at', { ascending: false })
      .then(({ data }) => {
        if (data) setReviews(data as Review[]);
        setLoading(false);
      });
  }, [productId]);
  return { reviews, loading };
}

export function useSettings() {
  const [settings, setSettings] = useState<Settings | null>(null);
  useEffect(() => {
    supabase
      .from('settings')
      .select('*')
      .eq('id', 1)
      .maybeSingle()
      .then(({ data }) => data && setSettings(data as Settings));
  }, []);
  return settings;
}

export function useX300Specs() {
  const [specs, setSpecs] = useState<X300Specs | null>(null);
  useEffect(() => {
    supabase
      .from('x300fe_specs')
      .select('*')
      .eq('id', 1)
      .maybeSingle()
      .then(({ data }) => data && setSpecs(data as X300Specs));
  }, []);
  return specs;
}
