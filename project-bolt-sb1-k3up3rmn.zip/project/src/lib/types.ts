export type Role = 'customer' | 'admin' | 'super_admin';

export interface Brand {
  id: string;
  name: string;
  slug: string;
  logo_url: string | null;
  country: string | null;
  featured: boolean;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string | null;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  brand_id: string | null;
  category_id: string | null;
  short_description: string | null;
  description: string | null;
  price: number;
  compare_price: number | null;
  images: string[];
  stock: number;
  rating: number;
  reviews_count: number;
  is_featured: boolean;
  is_published: boolean;
  launch_date: string | null;
  tags: string[];
  variants: Record<string, string[]>;
  specs: Record<string, string>;
  created_at: string;
  updated_at: string;
}

export interface Review {
  id: string;
  product_id: string;
  user_id: string | null;
  author_name: string | null;
  rating: number;
  title: string | null;
  body: string | null;
  approved: boolean;
  created_at: string;
}

export interface Offer {
  id: string;
  title: string;
  subtitle: string | null;
  image_url: string | null;
  badge: string | null;
  cta_text: string | null;
  cta_link: string | null;
  active: boolean;
  sort_order: number;
}

export interface X300Specs {
  id: number;
  price: number;
  status: string;
  launch_date: string | null;
  colors: string[];
  platform: Record<string, string>;
  memory: Record<string, string>;
  battery: Record<string, string>;
  design: Record<string, string>;
  display: Record<string, string>;
  camera: Record<string, string>;
  connectivity: Record<string, string>;
  sensors: string[];
  box_contents: string[];
  warranty: string | null;
  faqs: { q: string; a: string }[];
}

export interface Settings {
  id: number;
  store_name: string;
  accent_primary: string;
  accent_secondary: string;
  contact_phone1: string;
  contact_phone2: string;
  contact_phone3: string;
  address: string;
  whatsapp: string;
  theme_switch_enabled: boolean;
}

export interface Profile {
  id: string;
  full_name: string | null;
  phone: string | null;
  role: Role;
  created_at: string;
}

export interface CartItem {
  product_id: string;
  name: string;
  slug: string;
  image: string;
  price: number;
  quantity: number;
  variant?: { color?: string; storage?: string; ram?: string };
}

export interface OrderRow {
  id: string;
  user_id: string;
  status: string;
  total: number;
  shipping_address: Record<string, string>;
  payment_method: string;
  created_at: string;
  updated_at: string;
}

export interface OrderItemRow {
  id: string;
  order_id: string;
  product_id: string | null;
  name: string;
  image_url: string | null;
  variant: Record<string, string>;
  price: number;
  quantity: number;
}

export const ORDER_STATUSES = [
  'Pending',
  'Confirmed',
  'Processing',
  'Shipped',
  'Delivered',
  'Cancelled',
] as const;
